"""Passive counters for one serial QA job. Only stage names, numbers and monotonic spans leave this process."""
from collections import Counter
from contextlib import contextmanager
from threading import Event, Thread
from time import monotonic
from urllib.parse import urlsplit

from resource_sample import ResourceSample, window

STAGES = frozenset('queue browser restore login map settings dom pixels hover measure compute validate capture source_save analysis result_save display refresh close wait'.split())
COUNTERS = frozenset('db_reads db_writes db_queries db_connections db_affected db_conflicts browser_launch browser_close login_submit dom_batch dom_repeat hover_try hover_ok measure_try measure_ok measure_values screenshots screenshot_bytes source_bytes result_bytes rail_rows hover_unique duplicates overlaps groups_above groups_below missing ai_requests ai_responses ai_repair retry source_read receipt_read checksum_checks mouse_move mouse_down mouse_up page_evaluate locator_evaluate locator_count wait_calls'.split())

class PilotTelemetry:
    def __init__(self, interval=.45):
        self.samples=ResourceSample()
        self.interval=interval
        self.stop=Event()
        self.worker=None
        self.stack=[]
        self.spans=[]
        self.counters=Counter()
        self.events=Counter()
        self.pages=set()
        self.context_ids=set()
        self.peak_tabs=0
        self.closed_tabs=0
        self.opened_tabs=0
        self.wait_s=Counter()
        self.at=monotonic()
        self.finished=False

    def __enter__(self):
        def sample():
            while not self.stop.wait(self.interval):self.samples.update()
        self.worker=Thread(target=sample,daemon=True)
        self.worker.start()
        return self

    def __exit__(self,*_):
        self.stop.set()
        if self.worker is not None:self.worker.join(timeout=2)
        self.samples.update(force=True)
        self.finished=True

    @contextmanager
    def phase(self,name):
        if name not in STAGES:raise ValueError('unknown_telemetry_stage')
        self.stack.append(name)
        start=monotonic()
        try:yield
        finally:
            self.stack.pop()
            self.spans.append((name,start,monotonic()))

    def count(self,name,n=1):
        if name in COUNTERS and type(n) is int and n>=0:self.counters[name]+=n

    def current(self):
        return self.stack[-1] if self.stack else 'unassigned'

    @contextmanager
    def browser_actions(self):
        """Count explicit page waits and pointer/screenshot primitives; no arguments, images, or DOM data are recorded."""
        from playwright.sync_api import Mouse, Page, Locator
        from contextlib import ExitStack
        from unittest.mock import patch
        from functools import wraps
        def replacement(fn,key):
            @wraps(fn)
            def call(obj,*args,**kwargs):
                self.count(key);start=monotonic()
                try:return fn(obj,*args,**kwargs)
                finally:
                    if key=='wait_calls':self.wait_s[self.current()]+=monotonic()-start
            return call
        with ExitStack() as stack:
            for cls,attr,key in ((Page,'wait_for_timeout','wait_calls'),(Page,'evaluate','page_evaluate'),
                        (Locator,'evaluate','locator_evaluate'),(Locator,'count','locator_count'),(Page,'screenshot','screenshots'),
                        (Mouse,'move','mouse_move'),(Mouse,'down','mouse_down'),(Mouse,'up','mouse_up')):
                stack.enter_context(patch.object(cls,attr,replacement(getattr(cls,attr),key)))
            yield

    def attach(self,context):
        """Call immediately on creation. Does not read headers, request/response bodies or account identifiers."""
        if id(context) in self.context_ids:return
        self.context_ids.add(id(context))
        def page_open(page):
            key=id(page)
            if key in self.pages:return
            self.pages.add(key);self.opened_tabs+=1;self.peak_tabs=max(self.peak_tabs,len(self.pages))
            def closed(*_):
                if key in self.pages:
                    self.pages.remove(key);self.closed_tabs+=1
            page.on('close',closed)
        def observe(kind,request):
            try:
                host=(urlsplit(request.url).hostname or '').lower()
                party='source' if host=='coinglass.com' or host.endswith('.coinglass.com') else 'other'
                rt=request.resource_type
                if rt not in ('document','stylesheet','image','media','font','script','xhr','fetch','websocket'):
                    rt='other'
                self.events[(self.current(),kind,party,rt)]+=1
                if kind=='request' and request.is_navigation_request() and request.frame.parent_frame is None:
                    self.events[(self.current(),'main_navigation',party,'document')]+=1
            except Exception:
                self.counters['observer_unknown']+=1
        context.on('page',page_open)
        for page in context.pages:page_open(page)
        context.on('request',lambda req:observe('request',req))
        context.on('requestfailed',lambda req:observe('failure',req))
        def error_status(resp):
            if resp.status in (401,403,429) or resp.status>=500:observe('http_'+str(resp.status) if resp.status<500 else 'http_5xx',resp.request)
        context.on('response',error_status)

    def report(self):
        if not self.finished:raise RuntimeError('finish_telemetry_first')
        report=self.samples.report()
        data=report.pop('samples')
        return {'whole':report, 'phases':[{'stage':k,'start_mono_s':a,'end_mono_s':b,**window(data,a,b)} for k,a,b in self.spans],
                'counters':dict(self.counters),'network':[[*key,n] for key,n in sorted(self.events.items())],
                'opened_tabs':self.opened_tabs,'closed_tabs':self.closed_tabs,'peak_tabs':self.peak_tabs,
                'explicit_wait_seconds_by_phase':dict(self.wait_s)}
