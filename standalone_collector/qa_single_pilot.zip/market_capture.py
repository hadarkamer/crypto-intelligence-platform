"""Source-visible QA facts and a chart-only PNG. Never read submission or account data."""
import base64
import hashlib
from io import BytesIO

from PIL import Image, ImageChops

TARGET = 'https://www.coinglass.com/LiquidationHeatMap/BTC?mode=coin'
SCHEMA = 'market_only_canvas.v1'
MAX_IMAGE = 1_400_000
# Construct an image strictly from the visible chart rectangle on screen. A
# visible gate, offscreen geometry or foreign overlay prevents image capture.
SURFACE = r"""target => {
 const S={symbol:null,model:null,mode:null,range:null,layout:null,lens:null,palette:null,theme:null,intensity_low_pct:null,intensity_high_pct:null,count:null};
 const M={total:null,above:null,below:null,price_step:null,column_period:null,updated_marks:[],rail_sample:[]};
 const out={schema:'market_only_canvas.v1',capture_status:'not_target',settings:S,market:M,geometry:null,shape:{}};
 if(location.href!==target || location.origin!=='https://www.coinglass.com')return out;
 const sec='form,header,nav,footer,aside[aria-label*="account" i],[contenteditable=true],input,textarea,iframe,dialog,[role=dialog]';
 const norm=s=>(s||'').trim().replace(/\s+/g,' ');
 const visible=e=>{if(!e||e.closest('[hidden],[inert],[aria-hidden=true]'))return false;
  const r=e.getBoundingClientRect(); if(!r.width||!r.height||r.right<=0||r.bottom<=0||r.left>=innerWidth||r.top>=innerHeight)return false;
  for(let n=e;n&&n!==document;n=n.parentElement){const st=getComputedStyle(n);if(st.display==='none'||st.visibility==='hidden'||Number(st.opacity)===0)return false}return true};
 const selected=e=>e.matches('[aria-selected=true],[aria-pressed=true],[data-state=active]')||[...e.classList].some(k=>/(?:^|_)(?:active|selected|on)(?:__|$)/i.test(k));
 const pool=[...document.querySelectorAll('div,span,p,strong,small,time,h1,h2,h3,h4,li,button,label,[role=tab],[role=combobox],[data-lv]')].filter(e=>!e.closest(sec)&&e.childElementCount<7&&e.textContent.length<145&&visible(e));
 const text=e=>norm(e.innerText);
 const find=s=>pool.filter(e=>text(e).toLowerCase()===s.toLowerCase());
 const controls=pool.filter(e=>e.matches('li,button,[role=tab],[role=combobox]'));
 const headings=find('BTC Liquidation Heatmap');
 const b=controls.some(e=>text(e)==='BTC')&&headings.length>0;
 S.symbol=b?'BTC':null;
 function active(values) {
  const found=values.filter(v=>controls.some(e=>text(e).toLowerCase()===v.toLowerCase()&&selected(e)));
  return found.length===1?found[0]:null;
 }
 S.model=active(['Model 1','Model 2','Model 3']); S.mode=active(['Coin','Pair']);
 S.count=active(['Right edge','Entire box']);
 function combo(label,choices) {
  const vals=new Set();
  for(const l of find(label)){let p=l;for(let depth=0;depth<5&&p&&p.tagName!=='BODY';depth++,p=p.parentElement){
   const cb=[...p.querySelectorAll('[role=combobox],select')].filter(e=>visible(e)&&!e.closest(sec));
   if(cb.length===0)continue;if(cb.length!==1)break;
   const value=text(cb[0]);const known=choices.find(([rg])=>rg.test(value));if(known)vals.add(known[1]);break;
  }}return vals.size===1?[...vals][0]:null;
 }
 const opts=a=>a.map(v=>[new RegExp('^'+v+'$','i'),v]);
 S.range=combo('Range',opts(['12 hour','24 hour','48 hour']));
 S.layout=combo('Layout',opts(['Single chart','Dual chart','Split chart']));
 S.lens=combo('Lens',opts(['Heat','Delta','Liquidity','Liquidations']));
 S.palette=combo('Colours',[[/^Viridis(?:\s*Default)?$/i,'Viridis'],...opts(['Plasma','Inferno','Magma','Turbo'])]);
 const themes=new Set();
 const root=document.documentElement,body=document.body;
 for(const e of [root,body]){
  for(const k of ['data-theme','data-color-scheme','data-mui-color-scheme']){
   const v=e.getAttribute(k);if(/^(?:dark|light)$/i.test(v))themes.add(v.toLowerCase());
  }
  for(const c of e.classList)if(/^(?:dark|light)$/i.test(c))themes.add(c.toLowerCase());
 }
 if(themes.size===1)S.theme=[...themes][0]==='dark'?'Dark':'Light';
 const levels={total:'Open liquidation levels (total)',above:'Shorts (above price)',below:'Longs (below price)'};
 const escape=s=>s.replace(/[.*+?^${}()|[\]\\]/g,'\\$&');
 const amount='(?:[€$£]\\s*)?\\d[\\d,.]*(?:\\s*[KMBT])?';
 function numericAfter(label,pattern){
  const regs=new Set();
  for(const l of find(label)){let n=l;for(let i=0;i<5&&n&&n.tagName!=='BODY';i++,n=n.parentElement){
    if(n.closest(sec)||n.textContent.length>720)break;
    const m=norm(n.innerText).match(new RegExp('(?:^|\\s)'+escape(label)+'\\s*[:·]?\\s*('+pattern+')(?=$|\\s|[•·])','i'));
    if(m){regs.add(m[1]);break}
  }}return regs.size===1?[...regs][0]:null;
 }
 for(const [k,l] of Object.entries(levels))M[k]=numericAfter(l,amount);
 const step=numericAfter('Price step / column period',amount+'\\s*/\\s*\\d{1,3}\\s*(?:s|m|h|min|minutes?)');
 if(step){[M.price_step,M.column_period]=step.split('/').map(norm)}
 const mark=/^Updated(?:\s+at|\s*[:·])?\s+(?:(?:\d{4}-\d{2}-\d{2}[ T])?\d{1,2}:\d{2}(?::\d{2})?(?:\s*[AP]M)?(?:\s*(?:UTC|GMT)(?:[+-]\d{1,2}(?::\d{2})?)?)?|just now|\d{1,3}\s*(?:min|minutes?|seconds?|s|m)(?:\s+ago)?)$/i;
 M.updated_marks=[...new Set(pool.map(text).filter(t=>mark.test(t)))].slice(0,4);
 const rail=pool.filter(e=>e.matches('[data-lv]'));
 const price=/^\d[\d,]{0,14}(?:\.\d{1,12})?$/;
 M.rail_sample=[...new Set(rail.flatMap(e=>e.innerText.split(/\n/).map(norm)).filter(t=>price.test(t)))].slice(0,12);
 const intensity=find('Intensity');
 for(const l of intensity){for(let n=l.parentElement,d=0;n&&n.tagName!=='BODY'&&d<5;d++,n=n.parentElement){
   if(n.textContent.length>420)break;
   const t=text(n),lo=t.match(/(?:≥|>=)\s*(\d{1,3})\s*%/),hi=t.match(/(?:≤|<=)\s*(\d{1,3})\s*%/);
   if(lo&&hi&&+lo[1]<=100&&+hi[1]<=100){S.intensity_low_pct=+lo[1];S.intensity_high_pct=+hi[1];break}
 }}
 out.shape={rail_count:Math.min(255,rail.length),price_step_caption:!!find('Price step / column period').length,market_overview:!!find('Market overview').length,update_marker_count:M.updated_marks.length};
 if(!(S.symbol==='BTC'&&S.model==='Model 1'&&S.mode==='Coin'&&S.range==='12 hour')){out.capture_status='identity_unconfirmed';return out;}
 const canv=[...document.querySelectorAll('canvas')].filter(e=>!e.closest(sec)&&visible(e)).map(e=>({e,r:e.getBoundingClientRect()})).filter(({r})=>r.width>=400&&r.height>=200).sort((a,b)=>b.r.width*b.r.height-a.r.width*a.r.height);
 if(!canv.length){out.capture_status='canvas_unavailable';return out}
 const r=canv[0].r, box={x:Math.round(r.x),y:Math.round(r.y),width:Math.round(r.width),height:Math.round(r.height)};
 const same=({r:z})=>Math.abs(z.left-r.left)<2&&Math.abs(z.top-r.top)<2&&Math.abs(z.width-r.width)<2&&Math.abs(z.height-r.height)<2;
 const group=canv.filter(same);
 out.geometry={...box,layer_count:group.length};
 if(r.x<0||r.y<0||r.right>innerWidth+1||r.bottom>innerHeight+1||box.width>2048||box.height>1600||group.length>8){out.capture_status='canvas_geometry_unavailable';return out}
 const crosses=e=>{const z=e.getBoundingClientRect();return z.right>r.left&&z.left<r.right&&z.bottom>r.top&&z.top<r.bottom};
 const overlay=[...document.querySelectorAll('dialog,[role=dialog],.MuiModal-root,[aria-modal=true],iframe,input[type=password],[role=alert],header,nav,form')].filter(e=>visible(e)&&crosses(e));
 const chartGate=/(?:log\s*in|sign\s*in) to (?:unlock (?:the )?full data|view (?:the )?liquidation heatmap)|(?:upgrade|subscribe) to (?:unlock|view)|verify (?:that )?you are human|captcha|verification code/i;
 const denied=pool.some(e=>chartGate.test(text(e)))||overlay.length>0;
 if(denied){out.capture_status='visible_restriction_or_private_overlay';return out;}
 for(const {e} of group){for(let n=e;n&&n.tagName!=='BODY';n=n.parentElement){
  const st=getComputedStyle(n);
  if(st.filter!=='none'||Number(st.opacity)<.99){out.capture_status='filtered_chart';return out}
 }}
 // Copy native chart drawables only. Never serialize the page, composed DOM or another frame.
 const blockedAt=(x,y)=>{const stack=document.elementsFromPoint(x,y);const idx=stack.findIndex(e=>group.some(g=>g.e===e));
  if(idx<0)return true;
  return stack.slice(0,idx).some(e=>!group.some(g=>g.e===e)&&!group.some(g=>e.contains(g.e))&&
     (e.closest(sec)||getComputedStyle(e).backdropFilter!=='none'&&getComputedStyle(e).backdropFilter!==undefined||
      (/captcha|(?:pay|auth|login).*wall|modal|backdrop|lock-overlay/i).test([e.className,e.getAttribute('role')].join(' '))));};
 for(const x of [.15,.5,.85])for(const y of [.15,.5,.85])if(blockedAt(r.left+x*r.width,r.top+y*r.height)){out.capture_status='obscured_chart';return out}
 const img=document.createElement('canvas');img.width=box.width;img.height=box.height;const g=img.getContext('2d');
 let bg='rgb(10, 13, 18)';for(let n=group[0].e;n;n=n.parentElement){
 const c=getComputedStyle(n).backgroundColor;if(/^rgb\(\d+,? \d+,? \d+\)$/.test(c)){bg=c;break}}
 g.fillStyle=bg;g.fillRect(0,0,img.width,img.height);
 const sameDomOrder=group.slice().sort((a,b)=>a.e.compareDocumentPosition(b.e)&Node.DOCUMENT_POSITION_FOLLOWING?-1:1);
 try{for(const{e} of sameDomOrder)g.drawImage(e,0,0,img.width,img.height);
 const data=img.toDataURL('image/png');if(data.length<=1866700){out.png=data.slice('data:image/png;base64,'.length);out.capture_status='captured'}else out.capture_status='pixel_budget';}
 catch(_){out.capture_status='chart_export_unavailable'}return out;
}"""


def capture(page):
    fallback = {'schema': SCHEMA, 'capture_status': 'observation_unavailable'}
    if page.url != TARGET:
        return dict(fallback, capture_status='not_target'), None
    try:
        data = page.evaluate(SURFACE, TARGET)
    except Exception:
        return fallback, None
    if not isinstance(data, dict) or data.get('schema') != SCHEMA:
        return fallback, None
    raw = data.pop('png', None)
    if data.get('capture_status') != 'captured' or not isinstance(raw, str) or len(raw) > 1_866_700:
        return data, None
    try:
        image = base64.b64decode(raw, validate=True)
        if len(image) > MAX_IMAGE or not image.startswith(b'\x89PNG\r\n\x1a\n'):
            raise ValueError()
        with Image.open(BytesIO(image)) as im:
            if im.size != (data['geometry']['width'], data['geometry']['height']):
                raise ValueError()
            im.verify()
        # Intersection with real opaque screen pixels is decisive: copying a
        # canvas must never reveal rows obscured on screen by a gate or overlay.
        if page.url!=TARGET:
            return dict(data,capture_status='not_target'),None
        area={k:data['geometry'][k] for k in ('x','y','width','height')}
        mask=page.locator('input,textarea,iframe,form,dialog,header,nav,[role=dialog],[role=alert],[contenteditable=true]')
        screened=page.screenshot(clip=area,mask=[mask],animations='disabled',timeout=2500)
        with Image.open(BytesIO(screened)) as shot, Image.open(BytesIO(image)) as canvas:
            if shot.size!=canvas.size:
                raise ValueError()
            with shot.convert('RGB') as visible, canvas.convert('RGB') as native:
                diff=ImageChops.difference(visible,native)
                bands=diff.split()
                peak=ImageChops.lighter(ImageChops.lighter(bands[0],bands[1]),bands[2])
                allowed=peak.point(lambda v:255 if v<=2 else 0)
                dark=Image.new('RGB',visible.size,(10,13,18))
                with Image.composite(native,dark,allowed) as safe:
                    pixels=sum(allowed.histogram()[1:])
                    data['visible_chart_match_pct']=round(100*pixels/(safe.width*safe.height),1)
                    if not pixels:
                        return dict(data,capture_status='no_visible_chart_pixels'),None
                    out=BytesIO();safe.save(out,'PNG');image=out.getvalue()
        if len(image)>MAX_IMAGE:
            return dict(data,capture_status='pixel_budget'),None
        data['image_sha256']=hashlib.sha256(image).hexdigest()
        return data,image
    except Exception:
        return dict(data,capture_status='invalid_canvas_png'), None
