"""Read back only job-bound chart receipts. No provider or model, no account-state reads."""
import base64, hashlib, json, os, sys
from pathlib import Path
from uuid import UUID
directory, job, digest = sys.argv[1:]
sys.path[:0] = [directory, str(Path(directory)/'runtime')]
from market_vault import analysis_record
from psycopg import connect
from psycopg.rows import dict_row
assert str(UUID(job)) == job
try:
    with connect(os.environ['DATABASE_URL'],row_factory=dict_row,connect_timeout=4,autocommit=True) as conn:
        conn.execute('SET default_transaction_read_only=on')
        key=base64.b64decode(os.environ['COINGLASS_SESSION_KEY'],validate=True)
        records = {kind: analysis_record(conn,key,job,digest,kind)[1]
                   for kind in ('claim','verdict','budget','result')}
    print(json.dumps({'job_id':job,'chart_journal_readback':{k:v is not None for k,v in records.items()},
                      'result_sha256':hashlib.sha256(records['result']).hexdigest() if records['result'] else None,
                      'requests':json.loads(records['budget']).get('requests') if records['budget'] else None}))
except Exception as error:
    print(json.dumps({'chart_journal_readback':'failed','reason':type(error).__name__}))
    raise SystemExit(1)
