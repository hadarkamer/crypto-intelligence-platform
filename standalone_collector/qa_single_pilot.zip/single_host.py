"""Bounded one-service QA listener. Secrets are passed only to their respective worker."""
import base64
from hashlib import sha256
import json
import os
from pathlib import Path
import re
import subprocess
import sys
from threading import Thread
import time
from zipfile import ZipFile

HERE=Path(__file__).resolve().parent
STAND=HERE.parent
ROOT=Path('/tmp/cg-budget')
SERVICE='decision-hub-coinglass-pilot-20261125'
BRANCH='qa/coinglass-single-verified-20261126e'
CLEAN=('PATH','HOME','LANG','LD_LIBRARY_PATH','VIRTUAL_ENV','PLAYWRIGHT_BROWSERS_PATH','XDG_CACHE_HOME')
SOURCE=('DATABASE_URL','COINGLASS_SESSION_KEY','COINGLASS_LOGIN_EMAIL','COINGLASS_LOGIN_PASSWORD')
ANALYSIS=('DATABASE_URL','COINGLASS_SESSION_KEY','OPENAI_API_KEY','OPENAI_MARKET_SCANNER_MODEL')

def load(name,default=None):
    f=ROOT/name
    return json.loads(f.read_text()) if f.is_file() else default

def emit(k,data=None):
    print('SINGLE_QA_'+k, json.dumps(data,separators=(',',':')) if data is not None else '',flush=True)

def run_child(script,args,env,timeout):
    import signal
    with (ROOT/(script.stem+'.log')).open('wb') as log:
        proc=subprocess.Popen([sys.executable,'-B','-u',str(script),*args],env=env,stdin=subprocess.DEVNULL,
                      stdout=log,stderr=subprocess.STDOUT,close_fds=True,start_new_session=True)
        try:return proc.wait(timeout=timeout)
        except subprocess.TimeoutExpired:
            os.killpg(proc.pid,signal.SIGKILL);proc.wait(timeout=5)
            raise ValueError('bounded_worker_timeout') from None

def settle(job,clean,source_env,analysis_env,deadline):
    from qa_job_server import write_once
    source=None;analysis=None;result=None;metrics=None;readback=None
    err='source_not_readable';stage='source'
    begun=time.monotonic()
    try:
        emit('SOURCE_START',job)
        run_child(HERE/'single_source.py',[job],clean|source_env,min(395,max(1,deadline-time.time()-65)))
        source=load('source-receipt.json')
        if source is None:raise ValueError('source_worker_exited_before_receipt')
        emit('SOURCE_DONE',{'job':job,'stage':source.get('stage'),'numeric':source.get('numeric_read'),'failure':source.get('failure')})
        ref=source.get('market_vault') or {}
        if source.get('numeric_read')=='verified' and ref.get('readback') is True and ref.get('job')==job:
            if not source.get('supplement_vault',{}).get('private_readback'):raise ValueError('source_supplement_not_stored')
            stage='analysis';err='chart_analysis_incomplete'
            from resource_sample import ResourceSample
            start=time.monotonic();meter=ResourceSample()
            import threading
            stop=threading.Event()
            def sampler():
                while not stop.wait(.45):meter.update()
            t=threading.Thread(target=sampler,daemon=True);t.start()
            try:
                if not analysis_env.get('OPENAI_API_KEY'):raise ValueError('analysis_key_missing')
                emit('ANALYSIS_START',job)
                run_child(HERE/'analyst'/'market_worker.py',['settle',job,ref['sha256'],str(ref['oid'])],
                          clean|analysis_env,min(110,max(1,deadline-time.time()-13)))
            finally:
                stop.set();t.join(1);metrics=meter.report();metrics.pop('samples',None)
                metrics['wall_seconds']=round(time.monotonic()-start,3)
            from retained_evidence import safe_root
            budget=safe_root()/(job+'.analysis-budget.json')
            if budget.is_file():analysis=json.loads(budget.read_text())
            finished=HERE/'analyst'/'normalized-market-receipt.json'
            if finished.is_file():
                receipt=json.loads(finished.read_text())
                payload=base64.b64decode(receipt['result_b64'],validate=True)
                normal=json.loads(payload)
                if (sha256(payload).hexdigest()!=receipt['result_sha256'] or receipt['job_id']!=job or normal['run_id']!=job or
                    (normal['symbol'],normal['heatmap_model'],normal['timeframe'])!=('BTC',1,'12H') or
                    normal['evidence']['sha256']!=source['chart_sha256']):raise ValueError('app_result_binding_failed')
                # Independently re-open the durable owner-only journal after the settlement commit.
                db_only={k:source_env[k] for k in ('DATABASE_URL','COINGLASS_SESSION_KEY')}
                run_child(HERE/'verify_settlement.py',[str(HERE/'analyst'),job,ref['sha256']],
                          clean|db_only, min(8,max(1,deadline-time.time()-3)))
                readback=json.loads((ROOT/'verify_settlement.log').read_text())
                if (readback.get('job_id')!=job or readback.get('result_sha256')!=receipt['result_sha256']
                    or readback.get('requests')!=1 or not all(readback.get('chart_journal_readback',{}).get(k)
                    for k in ('claim','verdict','budget','result'))):
                    raise ValueError('private_result_readback_failed')
                result=normal
    except Exception as exc:
        emit('SETTLE_ERROR',{'stage':stage,'class':type(exc).__name__,
                'code':str(exc) if re.fullmatch('[a-z_]{1,64}',str(exc)) else None})
    source=source or {'missing_receipt':True}
    out=dict(job_id=job,source_receipt=source,snapshot=load('snapshot.json'),
             supplement=load('market-supplement.json'),metrics=dict(source=load('source-metrics.json'),analysis=metrics,
                 collector_wall_seconds=round(time.monotonic()-begun,3)),analysis=analysis,
             application_state='ready' if result else 'failed',chart_png_b64=None,chart_sha256=None,
             analysis_journal_readback=readback)
    png=next((p for n in ('chart-final.png','chart-observation.png') if (p:=ROOT/n).is_file()),None)
    if png and png.stat().st_size<=1300000:
        raw=png.read_bytes();out.update(chart_png_b64=base64.b64encode(raw).decode(),chart_sha256=sha256(raw).hexdigest())
    if len(json.dumps(out).encode())>3*1024**2:
        out['chart_png_b64']=None
    write_once('qa-export.json',out)
    write_once('ui_final.json',dict(job_id=job,status=out['application_state'],result=result,
        error=None if result else {'code':err,'message':'Verified collection is incomplete. See the job-bound QA receipt.'}))
    emit('FINISHED',{'job_id':job,'state':out['application_state'],'retained':source.get('supplement_vault')})

def serve():
    os.umask(0o077)
    if os.environ.get('RENDER_SERVICE_NAME')!=SERVICE or os.environ.get('RENDER_GIT_BRANCH')!=BRANCH:
        raise ValueError('isolated_service_required')
    service=os.environ['RENDER_SERVICE_ID']
    if service=='srv-dakhacou01pc73f58aug' or not re.fullmatch('srv-[a-z0-9]+',service):raise ValueError('unexpected_service')
    ROOT.mkdir(mode=0o700,exist_ok=True)
    for key in ('source', 'analysis','native'):
        if (ROOT/('started-'+key)).exists():raise ValueError('same_instance_restart')
    (ROOT/'started-native').touch(mode=0o600,exist_ok=False)
    sys.path[:0]=[str(HERE),str(STAND),str(STAND.parent)]
    from qa_job_server import make_server,write_once
    pin=json.loads((HERE/'app-pin.json').read_text())
    now=time.time()
    lifespan=11.5*60
    deadline=now+lifespan
    write_once('trial.json',{'service':service,'created_epoch':now-1})
    write_once('ui-ready.json',dict(pin,service=service,deadline=deadline))
    clean={k:os.environ[k] for k in CLEAN if k in os.environ}
    clean['PYTHONPATH']=os.pathsep.join((str(HERE),str(STAND),str(STAND.parent)))
    clean['PYTHONDONTWRITEBYTECODE']='1'
    clean['TZ']='UTC'
    source_env={k:os.environ.pop(k) for k in SOURCE if k in os.environ}
    analysis_env={k:(source_env[k] if k in source_env else os.environ.pop(k))
                  for k in ANALYSIS if k in source_env or k in os.environ}
    port=int(os.environ.get('PORT','10000'))
    def wait_one():
        from cycle_job import read_job
        while time.time()<deadline-145:
            try:job=read_job(ROOT,service);break
            except FileNotFoundError:time.sleep(.15)
        else:return
        (ROOT/'trial-started').touch(mode=0o600,exist_ok=False)
        settle(job,clean,source_env,analysis_env,deadline)
    with make_server(port,service) as server:
        Thread(target=wait_one,daemon=True).start()
        emit('ARMED',{'run_id':pin['run_id'],'service':service,'revision':os.environ.get('RENDER_GIT_COMMIT')})
        server.serve_forever()

if __name__=='__main__':serve()
