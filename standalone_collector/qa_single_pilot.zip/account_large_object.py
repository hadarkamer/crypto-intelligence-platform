"""Account-only private QA artifact; uses the collector's current Postgres connection and AEAD.
It never creates a schema, changes grants, updates a canonical session row or persists plaintext.
"""
import hashlib
import hmac
from account_stage import _codec


def _id(key,slot,run):
    message=('cg-qa-account-proof-lo-v1:'+slot+':'+run).encode('ascii')
    return 0x40000000 | int.from_bytes(hmac.new(key,message,hashlib.sha256).digest()[:4],'big')


def _safe(conn,oid):
    row=conn.execute("""SELECT m.lomowner=(SELECT oid FROM pg_catalog.pg_roles WHERE rolname=current_user)
        AND current_setting('lo_compat_privileges')='off'
        AND NOT EXISTS (SELECT 1 FROM pg_catalog.aclexplode(coalesce(m.lomacl,pg_catalog.acldefault('L',m.lomowner))) p
         WHERE p.grantee<>m.lomowner) AS owner_only
        FROM pg_catalog.pg_largeobject_metadata m WHERE m.oid=%s::oid""",(oid,)).fetchone()
    if row and row['owner_only'] is not True: raise ValueError('account_artifact_acl_not_private')
    return bool(row)


def _read(conn,codec,oid):
    from session_state import STATE_LIMIT
    part=conn.execute('SELECT pg_catalog.lo_get(%s::oid,0,%s) AS payload',(oid,2*STATE_LIMIT+1)).fetchone()['payload']
    if not 0<len(part)<=2*STATE_LIMIT: raise ValueError('account_artifact_size')
    return codec._open(bytes(part).decode('ascii'),1)


def save(conn,key,slot,run,state,*,account_verified):
    if account_verified is not True: raise ValueError('account_proof_required')
    codec=_codec(key,slot,run)
    oid=_id(key,slot,run)
    from session_state import PgSessionStore
    with conn.transaction():
        PgSessionStore(conn,key)._require_lock()
        if _safe(conn,oid):
            if _read(conn,codec,oid)!=state: raise ValueError('account_artifact_expected_snapshot_changed')
        else:
            envelope=codec._seal(state,1).encode('ascii')
            actual=conn.execute('SELECT pg_catalog.lo_from_bytea(%s::oid,%s::bytea) AS oid',(oid,envelope)).fetchone()['oid']
            if actual!=oid or not _safe(conn,oid): raise ValueError('account_artifact_private_write_failed')
    return {'oid':oid,'version':1,'owner_only':True}


def load(conn,key,slot,run,oid):
    if oid!=_id(key,slot,run): raise ValueError('account_artifact_reference_mismatch')
    codec=_codec(key,slot,run)
    with conn.transaction():
        if not _safe(conn,oid): raise ValueError('account_artifact_missing')
        return _read(conn,codec,oid)
