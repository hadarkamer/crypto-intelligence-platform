"""One public-only native comparison. No credentials, account state, model, database, or submissions."""
import argparse
import datetime
import hashlib
import importlib.metadata
import json
import os
from pathlib import Path
import platform
import re
import time
from urllib.parse import urlsplit

import playwright
from playwright.sync_api import sync_playwright

HOME='https://www.coinglass.com/'
LOGIN=HOME+'login'
MAP=HOME+'LiquidationHeatMap/BTC?mode=coin'
TMP=Path('/tmp/cg-public-engines')
CHROME_PATHS=('/opt/google/chrome/chrome','/tmp/cg-public-engines/chrome/opt/google/chrome/chrome')
CONTEXT=dict(locale='en-US',timezone_id='UTC',color_scheme='dark',device_scale_factor=1,viewport={'width':1440,'height':1280})
ADS=re.compile(r'^https?://(?:[a-zA-Z0-9-]+\.)*(?:doubleclick\.net|googlesyndication\.com|google-analytics\.com|googletagmanager\.com)/')
HEADERS={'server':r'[A-Za-z0-9._/ -]{1,64}','content-type':r'[A-Za-z0-9/; =._-]{1,90}',
 'content-length':r'\d{1,12}','x-cache':r'(?:Hit|Miss|RefreshHit|Error|RedirectHit) from cloudfront',
 'x-amz-cf-pop':r'[A-Za-z]{3}\d{1,3}-[A-Z]\d{1,3}','age':r'\d{1,14}','date':r'[A-Za-z0-9,: -]{1,45}',
 'cache-control':r'[A-Za-z0-9=, -]{1,90}','retry-after':r'[A-Za-z0-9,: -]{1,55}',
 'x-nextjs-cache':r'[A-Za-z_-]{1,18}','x-powered-by':r'[A-Za-z0-9 ._-]{1,35}'}
STAGES=('chromium_collector','chrome_stable','firefox_playwright')


def utc(): return datetime.datetime.now(datetime.timezone.utc).isoformat(timespec='milliseconds')

def official(url):
    try:
        u=urlsplit(url)
        return u.scheme=='https' and u.hostname in ('www.coinglass.com','coinglass.com') and u.username is None and u.password is None and u.port in (443,None)
    except (ValueError,TypeError):return False


def safeurl(url):
    if not official(url):return 'other_origin'
    u=urlsplit(url)
    path=u.path if re.fullmatch(r'/(?:login|sign-in|signin|Liquidation(?:HeatMap)?(?:/BTC)?|pro/futures/LiquidationHeatMap(?:/BTC)?)?/?',u.path,re.I) else '/[official-page]'
    return u.scheme+'://'+u.hostname+path+('?mode=coin' if u.query=='mode=coin' else '')


class Stop(Exception):pass


VIEW=r"""()=>{
 const vis=e=>{const b=e.getBoundingClientRect();return b.width>0 && b.height>0 && getComputedStyle(e).visibility==='visible' && !e.closest('[hidden],[inert]')};
 const text=e=>(e.getAttribute('aria-label')||e.innerText||e.textContent||'').trim();
 const pws=[...document.querySelectorAll('input[type=password]:not([autocomplete=new-password])')].filter(vis);
 const forms=[];
 for(const pw of pws){
  const f=pw.form;if(!f)continue;
  const controls=[...f.elements].filter(vis);
  const es=controls.filter(e=>e.matches('input[type=email],input[autocomplete=username],input[placeholder="Email" i]')&&!e.disabled&&!e.readOnly);
  const ps=controls.filter(e=>e.matches('input[type=password]:not([autocomplete=new-password])'));
  const bs=controls.filter(e=>e.type==='submit'&&/^(login|log in|sign in)$/i.test(text(e)||e.value||''));
  if(es.length!==1||ps.length!==1||bs.length!==1||pw.disabled||pw.readOnly)continue;
  const b=bs[0], d=new URL(b.hasAttribute('formaction')?b.formAction:f.action,document.baseURI);
  const basic=new URL(f.action,document.baseURI);
  const method=b.hasAttribute('formmethod')?b.formMethod:f.method;
  const target=(b.getAttribute('formtarget')??f.getAttribute('target')??document.querySelector('base[target]')?.target??'').toLowerCase();
  const same=d.origin===location.origin&&basic.origin===location.origin&&!d.username&&!d.password&&!basic.username&&!basic.password;
  forms.push({method:method.toLowerCase()==='post'?'POST':'other',action_explicit:f.hasAttribute('action'),method_explicit:f.hasAttribute('method'),post:method.toLowerCase()==='post',self:['','_self'].includes(target),same_origin:same,
   action_path:same&&/^\/(?:login|signin|sign-in|account\/login|api\/user\/login)\/?$/i.test(d.pathname)&&!d.search&&!d.hash?d.pathname:null});
 }
 const page=(document.body?.innerText||'').slice(0,22000);
 const gate=/sign in to view (?:the )?liquidation heatmap/i.test(page);
 const status=performance.getEntriesByType('navigation')[0];
 const live=[...document.querySelectorAll('li,[role=tab],button')].filter(vis);
 const coin=live.filter(e=>(e.innerText||'').trim()==='Coin').some(e=>e.getAttribute('aria-selected')==='true'||e.getAttribute('aria-pressed')==='true'||[...e.classList].some(c=>/(?:^|_)(?:active|selected|on)(?:_|$)/i.test(c)));
 const btc=live.some(e=>(e.innerText||'').trim()==='BTC');
 return {email:[...document.querySelectorAll('input[type=email],input[autocomplete=username],input[placeholder="Email" i]')].filter(vis).length,
   password:pws.length,forms,nav_url:status?.name||'',nav_status:status?.responseStatus||null,gate,coin,btc,
   chart:[...document.querySelectorAll('canvas')].some(vis),heatmap_heading:/BTC Liquidation Heatmap/i.test(page),
   captcha:[...document.querySelectorAll('iframe[src*="recaptcha" i],iframe[src*="hcaptcha" i],iframe[src*="challenges.cloudflare.com" i],[data-sitekey],input[autocomplete=one-time-code]')].some(vis)||
       /verify (?:that )?you are human|complete (?:the|this) captcha|security verification required|checking your browser/i.test(page),
   denied:/automated (?:traffic|requests).{0,30}(?:denied|blocked|not allowed)|(?:your request|access) (?:was|has been) blocked/i.test(page),
   rate:/too many requests|rate limit exceeded/i.test(page),
   error_text:/^(?:404 )?Not Found(?: nginx(?:\/[\d.]+)?)?$/i.test(page.replace(/\s+/g,' ').trim())?page.replace(/\s+/g,' ').trim():null};
}"""

FIND=r"""kind=>{
const vis=e=>{const r=e.getBoundingClientRect();return r.width>0&&r.height>0&&getComputedStyle(e).visibility==='visible'&&!e.closest('[hidden],[inert]')};
const label=e=>(e.getAttribute('aria-label')||e.innerText||'').trim();
for(const e of document.querySelectorAll('a[href],button,[role=tab],li,[role=menuitem]')){
 if(!vis(e)||e.disabled||e.closest('form'))continue;
 const a=e.closest('a[href]'), u=a?new URL(a.href):null;
 if(a && (u.protocol!=='https:'||u.origin!==location.origin||u.username||u.password||u.hash||a.hasAttribute('download')||
     !['','_self','_blank'].includes((a.getAttribute('target')||document.querySelector('base[target]')?.target||'').toLowerCase())))continue;
 let good=false;const t=label(e);
 if(kind==='login')good=/^(?:login|log in|sign in)$/i.test(t) && (a?e===a: e.tagName==='BUTTON');
 if(kind==='target')good=!!a&&e===a&&a.href==='https://www.coinglass.com/LiquidationHeatMap/BTC?mode=coin';
 if(kind==='intermediate')good=!!a&&e===a&&a.href!==location.href&&/heat\s*map/i.test(t)&&
    /^\/(?:pro\/futures\/)?LiquidationHeatMap(?:\/BTC)?\/?$/i.test(u.pathname)&&(!u.search||u.search==='?mode=coin');
 if(kind==='menu')good=/^liquidations?$/i.test(t)&&(e.tagName==='BUTTON'||e===a||e.getAttribute('role')==='menuitem');
 if(kind==='coin')good=/^\/(?:pro\/futures\/)?LiquidationHeatMap(?:\/BTC)?\/?$/i.test(location.pathname)&&t==='Coin'&&
   (e.getAttribute('role')==='tab'||e.tagName==='LI'||e.tagName==='BUTTON'||e===a) &&
   (!a||(/^\/(?:pro\/futures\/)?LiquidationHeatMap(?:\/BTC)?\/?$/i.test(u.pathname)&&(!u.search||u.search==='?mode=coin')));
 if(good)return e;
}return null}"""


def entry(page,kind):
    return page.evaluate_handle(FIND,kind).as_element()


def locate_binaries(pw,args):
    pkg=Path(playwright.__file__).resolve().parent/'driver/package'
    pins={x['name']:x['revision'] for x in json.loads((pkg/'browsers.json').read_text())['browsers']}
    roots=[pkg/'.local-browsers',Path.home()/'.cache/ms-playwright',Path('/ms-playwright'),TMP]
    env=os.environ.get('PLAYWRIGHT_BROWSERS_PATH')
    if env and env!='0':roots.insert(0,Path(env))
    cr=pins['chromium-headless-shell']
    chrome=args.chrome_path or next((x for x in CHROME_PATHS if Path(x).is_file()),CHROME_PATHS[0])
    if chrome not in CHROME_PATHS:raise ValueError('unapproved_chrome_path')
    head=[base/f'chromium_headless_shell-{cr}'/rel for base in roots for rel in ('chrome-linux/headless_shell','chrome-linux64/headless_shell','chrome-headless-shell-linux64/chrome-headless-shell')]
    firefox=Path(args.firefox_path or pw.firefox.executable_path)
    if not args.firefox_path and not firefox.exists() and (TMP/'firefox-path.txt').is_file():
        firefox=Path((TMP/'firefox-path.txt').read_text().strip())
    def accepted_ff(f):
        return f.name in ('firefox','firefox-bin') and any(f.is_relative_to(x.resolve()) for x in [*roots,TMP]) and (
            ('firefox-'+pins['firefox']) in f.parts or f.is_relative_to(TMP.resolve()))
    if not accepted_ff(firefox.resolve()):raise ValueError('unapproved_firefox_path')
    return {'chromium_collector':next((p for p in head if p.is_file()),head[0]),
            'chrome_stable':Path(chrome),'firefox_playwright':firefox}


def file_info(path):
    p=path.resolve(strict=True)
    h=hashlib.sha256()
    with p.open('rb') as f:
        if f.read(4)!=b'\x7fELF' or not os.access(p,os.X_OK):raise ValueError('not_browser_elf')
        f.seek(0)
        while data:=f.read(1<<20):h.update(data)
    return {'binary':p.name,'sha256':h.hexdigest(),'bytes':p.stat().st_size}


class Arm:
    def __init__(self,browser,name,deadline,global_stops):
        self.browser,self.name,self.end,self.stops=browser,name,deadline,global_stops
        self.rows=[];self.docs=[];self.phase='';self.failures={};self.received={};self.unbound={};self.events=[]

    def left(self,ms=12000):
        remaining=int((self.end-time.monotonic())*1000)
        if self.stops:raise Stop('provider_stop')
        if remaining<=0:raise Stop('arm_budget')
        return min(ms,max(1,remaining))

    def context(self):
        c=self.browser.new_context(**CONTEXT)
        c.route(ADS,lambda route:route.abort())
        c.on('response',self.response)
        c.on('requestfailed',self.failed)
        return c

    def failed(self,q):
        if not official(q.url):return
        key=self.phase+'/'+q.resource_type
        self.failures[key]=self.failures.get(key,0)+1

    def response(self,r):
        try:
            q=r.request
            if not official(r.url) and not (urlsplit(r.url).hostname or '').endswith('.coinglass.com'):return
            if r.status==429 or r.header_value('retry-after'):self.stops.add('rate_limit_or_retry_after')
            if not q.is_navigation_request():return
            try:frame=q.frame
            except Exception:frame=None
            if frame is not None and frame!=frame.page.main_frame:return
            if r.status in (401,403):self.stops.add('main_document_access_denied')
            heads={}
            for k,pat in HEADERS.items():
                value=r.header_value(k)
                if value and re.fullmatch(pat,value,re.I):heads[k]=value
            chain=[]; a=q.redirected_from;same=True
            while a and len(chain)<12:
                chain.append(safeurl(a.url));same=same and official(a.url);a=a.redirected_from
            record={'utc':utc(),'phase':self.phase,'url':safeurl(r.url),'status':r.status,'headers':heads,
                    'chain':list(reversed(chain))+[safeurl(r.url)],'official_chain':same and official(r.url) and not a}
            self.docs.append(record)
            if frame is not None:self.received[frame.page]=(r,record)
            else:self.unbound.setdefault(r.url,[]).append((r,record))
        except Exception:pass

    def observation(self,p,stage,start,offset):
        v=p.evaluate(VIEW); forms=v.pop('forms');navurl=v.pop('nav_url');timing=v.pop('nav_status')
        for key in ('captcha','denied','rate'):
            if v[key]:self.stops.add(key)
        observed=self.received.get(p)
        if not observed or observed[0].url!=navurl:
            candidates=self.unbound.get(navurl,[])
            observed=candidates[0] if len(candidates)==1 and candidates[0][0].status==timing else None
            if observed:self.received[p]=observed
        response=observed[0] if observed else None
        current=response.status if response else timing
        valid=bool(response and current and 200<=current<300 and official(p.url) and observed[1]['official_chain'])
        trusted=valid and len(forms)==1 and all(forms[0][k] for k in ('post','self','same_origin')) and not self.stops
        if response and 400<=response.status and int((observed[1]['headers'].get('content-length') or '0')) in range(1,16385):
            try:
                body=response.body()
                if len(body)<=16384:
                    observed[1]['decoded_body_bytes']=len(body);observed[1]['decoded_body_sha256']=hashlib.sha256(body).hexdigest()
            except Exception:pass
        title=p.title().strip()
        v['public_title']=title if title in ('404 Not Found','Not Found','CoinGlass','Login | CoinGlass','CoinGlass | Crypto, Stocks, Macro & Global Market Data') else ('empty' if not title else 'other')
        v.update(form=forms[0] if len(forms)==1 else None,form_count=len(forms),trusted_form=trusted)
        row={'stage':stage,'utc':utc(),'elapsed_ms':round((time.monotonic()-start)*1000),'final_url':safeurl(p.url),
             'current_document_status':current,'new_documents':self.docs[offset:],'rendered':v}
        self.rows.append(row)
        if self.stops:raise Stop('provider_stop')
        return row

    def goto(self,p,stage,url):
        self.phase=stage;start=time.monotonic();offset=len(self.docs)
        response=p.goto(url,wait_until='domcontentloaded',timeout=self.left())
        if response and 200<=response.status<300:
            p.wait_for_timeout(self.left(500))
            if stage in ('direct_login','direct_map'):
                cutoff=min(self.end,time.monotonic()+(6 if stage=='direct_login' else 3))
                while time.monotonic()<cutoff:
                    seen=p.evaluate(VIEW)
                    if seen['forms'] or seen['captcha'] or seen['denied'] or seen['rate'] or (
                            stage=='direct_map' and (seen['heatmap_heading'] or seen['gate'])):break
                    p.wait_for_timeout(self.left(160))
        return self.observation(p,stage,start,offset)

    def click(self,p,node,kind):
        self.phase=kind;start=time.monotonic();offset=len(self.docs);before=set(p.context.pages)
        node.click(timeout=self.left(9000),no_wait_after=True)
        active=p
        for _ in range(40 if kind=='ui_login' else 10):
            p.wait_for_timeout(self.left(180))
            added=[x for x in p.context.pages if x not in before]
            if len(added)>1:raise Stop('ambiguous_windows')
            if added:active=added[0]
            if active.url not in ('about:blank',) and not official(active.url):raise Stop('left_official_site')
            if kind=='ui_login':
                facts=active.evaluate(VIEW)
                if facts['forms'] or facts['captcha'] or facts['rate']:break
            elif active.url==MAP:break
        return active,self.observation(active,kind,start,offset)

    def ui(self,c):
        page=c.new_page()
        home=self.goto(page,'home',HOME)
        out={'map_via_ui':False,'trusted_form_via_ui':False,'map_path':'not_reached','form_path':'not_reached'}
        if not home['current_document_status'] or not 200<=home['current_document_status']<300:
            out.update(map_path='homepage_http_failure',form_path='homepage_http_failure');return out,None
        until=min(self.end,time.monotonic()+8)
        while time.monotonic()<until and not (entry(page,'login') or entry(page,'target') or entry(page,'menu')):
            page.wait_for_timeout(self.left(160))
        active=page; maprow=None; target=entry(active,'target')
        if not target:
            menu=entry(active,'menu')
            if menu:
                self.phase='map_menu';menu.hover(timeout=self.left(1800));page.wait_for_timeout(self.left(300));self.events.append('liquidation_menu_hover')
                target=entry(active,'target')
                if not target and not entry(active,'intermediate') and menu.evaluate("e=>e.tagName==='BUTTON'&&!e.form"):
                    menu.click(timeout=self.left(1500),no_wait_after=True);page.wait_for_timeout(self.left(300));self.events.append('liquidation_menu_expand')
                    target=entry(active,'target')
            if not target:
                mid=entry(active,'intermediate')
                if mid:
                    active,maprow=self.click(active,mid,'ui_heatmap')
                    target=entry(active,'target') if active.url!=MAP else None
                    if not target and active.url!=MAP:
                        coin=entry(active,'coin')
                        if coin:
                            active,maprow=self.click(active,coin,'ui_coin')
                            target=entry(active,'target') if active.url!=MAP else None
        if target:active,maprow=self.click(active,target,'ui_map')
        if maprow:
            obs=maprow['rendered'];doc=maprow['current_document_status']
            out['map_via_ui']=bool(active.url==MAP and doc and 200<=doc<300)
            out['map_path']=('canonical_public_gate' if obs['gate'] else 'canonical_ui' if out['map_via_ui'] else 'intermediate_only')
        else:out['map_path']='target_or_menu_unavailable'
        login=entry(active,'login')
        if not login and active!=page:active=page;login=entry(active,'login')
        if not login and active==page and active.url!=HOME:
            self.phase='history_back';start=time.monotonic();offset=len(self.docs)
            active.go_back(wait_until='domcontentloaded',timeout=self.left(6500));active.wait_for_timeout(self.left(450));self.observation(active,'history_back',start,offset)
            login=entry(active,'login')
        if login:
            active,row=self.click(active,login,'ui_login')
            out['trusted_form_via_ui']=row['rendered']['trusted_form'];out['form_path']='trusted_form' if out['trusted_form_via_ui'] else 'clicked_form_unconfirmed'
        else:out['form_path']='login_control_unavailable'
        return out,active if out['trusted_form_via_ui'] else None

    def run(self,retain=False,on_form_available=None):
        result={'name':self.name,'start':utc(),'rows':self.rows,'main_documents':self.docs,'events':self.events,'failures':self.failures,
                'ui':{},'errors':[],'retained':False}
        c=self.context();winner=None

        def offer(page,ctx,row):
            nonlocal winner
            if not retain or winner or self.stops or page is None or page.is_closed() or not row.get('rendered',{}).get('trusted_form'):return
            reference=self.received.get(page)
            if not reference or not reference[1]['official_chain'] or not 200<=reference[0].status<300:return
            doc=page.evaluate_handle('document')
            winner=(page,ctx,{'response':reference[0],'document':doc,'url':page.url,'stage':row['stage'],
                              'browser':self.name,'observed_utc':utc(),'observed_monotonic':time.monotonic()})
            if on_form_available:on_form_available({'browser':self.name,'stage':row['stage'],'utc':utc()})

        try:
            try:
                result['ui'],live=self.ui(c)
                if live is not None and self.rows:offer(live,c,self.rows[-1])
            except Stop:raise
            except Exception as exc:result['errors'].append({'stage':self.phase,'type':type(exc).__name__})
            for name,url in [('direct_login',LOGIN),('direct_map',MAP)]:
                self.left();direct=self.context()
                try:
                    pp=direct.new_page();row=self.goto(pp,name,url)
                    if name=='direct_login':offer(pp,direct,row)
                except Stop:raise
                except Exception as exc:result['errors'].append({'stage':name,'type':type(exc).__name__})
                finally:
                    if not winner or winner[1] is not direct:direct.close()
        except Stop as e:result['stopped']=str(e)
        finally:
            if not winner or winner[1] is not c:c.close()
            result['closed']=winner is None;result['end']=utc()
        return result,winner


def main(argv=None,on_live_form=None,on_form_available=None):
    parser=argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--chrome-path');parser.add_argument('--firefox-path')
    parser.add_argument('--arm-seconds',type=int,default=55)
    parser.add_argument('--inventory-only',action='store_true')
    parser.add_argument('--hold-seconds',type=int,default=90,help='Max post-comparison wait for a real preattached operator; ignored in ordinary CLI.')
    args=parser.parse_args(argv)
    if not 15<=args.arm_seconds<=90 or not 0<=args.hold_seconds<=120:raise ValueError('budget_invalid')
    permitted={'PATH','HOME','LANG','LC_CTYPE','LC_ALL','TZ','LD_LIBRARY_PATH','PLAYWRIGHT_BROWSERS_PATH','XDG_CACHE_HOME',
               'XDG_RUNTIME_DIR','SSL_CERT_FILE','SSL_CERT_DIR','PYTHONPATH','VIRTUAL_ENV','PYTHONDONTWRITEBYTECODE','PYTHONUTF8'}
    if not set(os.environ)<=permitted:raise ValueError('public_process_requires_clean_environment')
    report={'start':utc(),'context':CONTEXT,'arms':[],'provider_stops':[],'playwright':importlib.metadata.version('playwright'),
        'kernel':platform.release(),'machine':platform.machine(),'public_only':True}
    try:report['os']={k:v for k,v in platform.freedesktop_os_release().items() if k in ('ID','VERSION_ID')}
    except OSError:pass
    stops=set();env={k:os.environ[k] for k in ('HOME','PATH','LANG','LD_LIBRARY_PATH','PLAYWRIGHT_BROWSERS_PATH') if k in os.environ}
    with sync_playwright() as pw:
        paths=locate_binaries(pw,args)
        held=None
        try:
            for name in STAGES:
                if stops:break
                path=paths[name];row={'name':name,'start':utc()};browser=None
                try:
                    row.update(file_info(path))
                    if not args.inventory_only:
                        engine=pw.firefox if name=='firefox_playwright' else pw.chromium
                        launch={} if name=='firefox_playwright' else {'chromium_sandbox':True,'args':['--disable-dev-shm-usage']}
                        browser=engine.launch(executable_path=str(path),headless=True,timeout=15000,env=env,**launch)
                        row['browser_version']=browser.version
                        arm=Arm(browser,name,time.monotonic()+args.arm_seconds,stops)
                        facts,offer=arm.run(on_live_form is not None and held is None and args.hold_seconds>0,on_form_available)
                        row.update(facts)
                        if offer:held=(browser,*offer,row)
                except Exception as exc:
                    row.update(error='binary_missing' if isinstance(exc,FileNotFoundError) else 'arm_error',exception=type(exc).__name__)
                finally:
                    if browser is not None and (not held or held[0] is not browser):browser.close()
                report['arms'].append(row)
            if held and not stops:
                _,p,c,proof,winner=held
                if (not p.is_closed() and p.url==proof['url'] and proof['document'].evaluate('d=>d===document') and
                        200<=proof['response'].status<300):
                    # The external callback owns a bounded private approval wait after all other arms.
                    # It must recheck the same document and native form at the moment of a later approved action.
                    report['handoff']={'offered':True,'browser':proof['browser'],'stage':proof['stage'],'max_wait_seconds':args.hold_seconds}
                    on_live_form(p,c,args.hold_seconds,proof)
        finally:
            if held:
                held[2].close();held[0].close();held[4]['closed']=True
    report.update(end=utc(),provider_stops=sorted(stops),retained_contexts=0,public_credential_actions=0)
    print(json.dumps(report,separators=(',',':')),flush=True)


if __name__=='__main__':main()
