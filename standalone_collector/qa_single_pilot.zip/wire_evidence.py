"""Passive browser access evidence. Never inspect request payloads, headers, traces or page content."""
from urllib.parse import urlsplit


def _endpoint(raw):
    try:
        u=urlsplit(raw)
        if (u.scheme!='https' or u.username is not None or u.password is not None or u.port not in (None,443)
                or u.hostname not in ('coinglass.com','www.coinglass.com','capi.coinglass.com','fapi.coinglass.com')):
            return None
        return u.hostname,u.path.rstrip('/').lower()
    except (ValueError,TypeError):
        return None


ACCOUNT=('capi.coinglass.com','/coin-community/api/userapi/info')


class WireEvidence:
    def __init__(self, context):
        self.context=context
        self.armed=False
        self.observe_account_only=False
        self.native_action=None
        self.pending=set()
        self.statuses=[]
        self.api_accepted=False
        self.account_reply_status=None
        self.account_responses=[]
        self.posts=0

    def attach(self):
        self.context.on('request',self.request)
        self.context.on('response',self.response)

    def detach(self):
        self.context.remove_listener('request',self.request)
        self.context.remove_listener('response',self.response)

    def arm_after_durable_fence(self, native_form_action=None):
        if self.armed: raise ValueError('already_reserved')
        self.native_action=_endpoint(native_form_action) if native_form_action else None
        self.armed=True

    def request(self, req):
        if not self.armed or req.method!='POST': return
        key=_endpoint(req.url)
        if not key: return
        if key!=self.native_action and key[1].split('/')[-1] not in ('login','signin','sign-in'):
            return
        self.pending.add(req)
        self.posts+=1

    def response(self,res):
        if not self.armed and not self.observe_account_only: return
        if self.armed and res.request in self.pending:
            self.pending.remove(res.request)
            self.statuses.append(res.status)
        if _endpoint(res.url)==ACCOUNT and res.request.method=='GET':
            self.account_reply_status=res.status
            if res.status==200:
                self.account_responses.append(res)

    def account_envelope(self):
        # Called only after the observed page event completes, avoiding reads inside Playwright callbacks.
        # Never return provider data or use any private token/header to initiate a request.
        for reply in self.account_responses:
            try:
                envelope=reply.json()
                if isinstance(envelope,dict) and envelope.get('success') is True and envelope.get('data'):
                    self.api_accepted=True
            except Exception:
                pass
        self.account_responses.clear()
        return self.api_accepted

    def public(self):
        return {'actual_login_post_requests':self.posts,'actual_login_post_statuses':self.statuses[:4],
                'post_without_response':bool(self.pending),'account_info_http':self.account_reply_status,
                'authenticated_account_envelope':self.api_accepted}
