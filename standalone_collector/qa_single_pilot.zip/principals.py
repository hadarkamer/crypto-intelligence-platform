"""Ephemeral binding to a first-party login/current-user principal, without token or raw-ID retention."""
import hashlib
import hmac
import secrets

def account_objects(data):
    if not isinstance(data,dict):return []
    result=[(data,False)]
    for k in ('user','userInfo','account','profile','currentUser','userProfile'):
        candidate=data.get(k)
        if isinstance(candidate,dict):result.append((candidate,True))
    return result

class Binding:
    def __init__(self,clean=False):
        self.key=secrets.token_bytes(32)
        self.clean=bool(clean)
        self.accepted=False
        self.login=set()
        self.current=set()
        self.login_email_match=False
        self.login_email_different=False
        self.ambiguous=False
    def known(self,value):
        out=set()
        for record,typed in account_objects(value):
            names=('userId','userID','user_id','uid','accountId','account_id')
            if typed or any(k in record for k in ('email','userEmail','emailAddress','username','userName')):
                names=(*names,'id')
            for key in names:
                v=record.get(key)
                if type(v) not in (str,int):continue
                v=str(v)
                if 0<len(v)<=130 and len(v.strip())==len(v) and v not in ('0','-1','null','undefined'):
                    out.add(hmac.digest(self.key,v.encode(),'sha256'))
        return out
    def observe_login(self,body,digest):
        from ff_state import account_identity
        if not isinstance(body,dict) or body.get('success') is not True:return
        self.accepted=True
        data=body.get('data')
        self.login.update(self.known(data))
        identity=account_identity(data,digest)
        self.login_email_match |= identity=='match'
        self.login_email_different |= identity=='different'
    def observe_current(self,body):
        self.current.update(self.known(body))
    def link(self):
        if self.login_email_different:return 'different'
        if not self.clean or not self.accepted or not self.login or not self.current:return 'unknown'
        if len(self.login)!=1 or len(self.current)!=1:return 'unknown'
        return 'linked' if self.login==self.current else 'different'
    def restored(self):
        b=Binding(self.clean)
        b.key=self.key;b.accepted=self.accepted;b.login=self.login.copy();b.login_email_different=self.login_email_different
        return b
