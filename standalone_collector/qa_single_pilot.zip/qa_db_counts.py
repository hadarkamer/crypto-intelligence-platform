"""Count existing DB calls without recording SQL, arguments or results."""
class ObservedConnection:
    def __init__(self,connection,counts):
        self.connection=connection
        self.counts=counts
        counts['open_connections']+=1

    def __getattr__(self,key):
        return getattr(self.connection,key)

    def execute(self,query,*args,**kwargs):
        text=query.lower() if isinstance(query,str) else ''
        if 'lo_from_bytea(' in text: kind='writes'
        elif 'pg_try_advisory_lock(' in text: kind='locks'
        elif text.lstrip().startswith('select'): kind='reads'
        else: kind='other'
        self.counts[kind]+=1
        return self.connection.execute(query,*args,**kwargs)
