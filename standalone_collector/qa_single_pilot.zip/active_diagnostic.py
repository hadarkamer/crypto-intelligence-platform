"""Inspect the failed market document while still open. No page content or credentials leave the context."""
from pathlib import Path
import time

ROOT=Path('/tmp/cg-budget')

# Enumerate only affordances on the identified first-party chart promo card.
# Values are categorical. The model never receives marketing or account text.
ACTIONS=r"""state=>{
 const node=state.card;
 const facts=state.facts;
 if(!node || node.ownerDocument!==document || facts.cards!==1 || !node.isConnected)
   return {facts, controls:[], close:null};
 const namedClose=/^(?:close|dismiss)(?: (?:this )?(?:ad|advertisement|promo|promotion|banner|dialog|notification|popup))?[.!]?$/i;
 const exactLocale=/^(?:fermer|schließen|cerrar|fechar|chiudi|sluiten|luk|stäng|닫기|閉じる|关闭|關閉|סגור)$/i;
 const cross=/^(?:×|✕|✖|❌)$/;
 const normal=s=>String(s??'').trim().replace(/\s+/g,' ');
 const controls=[], accepted=[], unique=new Set();
 for(const e of node.querySelectorAll('button,[role=button],a[href],[aria-label],[title],svg,span,div')){
    const b=e.getBoundingClientRect();
    if(!b.width || !b.height || e.childElementCount>5 || !e.checkVisibility?.({checkOpacity:true,checkVisibilityCSS:true}))continue;
    const text=normal(e.innerText??e.textContent),a=normal(e.getAttribute('aria-label')),
          title=normal(e.getAttribute('title')), prox=e.closest('button,[role=button],a[href]');
    const closeName=[a,title,text].find(s=>namedClose.test(s)||exactLocale.test(s));
    const crossGlyph=cross.test(text), cls=e.getAttribute('class')||'', cursor=getComputedStyle(e).cursor;
    const classHint=/(?:close|dismiss)(?:Icon|Button|__|_|-|$)/i.test(cls);
    if(!closeName && !crossGlyph && !classHint && !prox)continue;
    const target=prox||e,role=target.tagName==='BUTTON'?'button':target.getAttribute('role')==='button'?'role_button':target.tagName==='A'?'link':'other';
    const tt=target.getBoundingClientRect(), hit=document.elementFromPoint((tt.left+tt.right)/2,(tt.top+tt.bottom)/2);
    const anchored=!!target.closest('a[href],form');
    const record={role,element:e.tagName.toLowerCase(),normal_close:!!closeName,
        name_kind:closeName===a&&a?'accessible_close':closeName===title&&title?'titled_close':closeName?'visible_close':null,
        glyph:crossGlyph, class_close_hint:classHint, pointer:cursor==='pointer',
        no_link_form:!anchored, hit:hit===target||target.contains(hit),disabled:!!target.disabled,
        position:[Math.round(tt.x),Math.round(tt.y),Math.round(tt.width),Math.round(tt.height)]};
    controls.push(record);
    if((role==='button'||role==='role_button') && closeName && !anchored && record.hit && !record.disabled &&
       !unique.has(target)&& target.getAttribute('aria-disabled')!=='true'){
       unique.add(target);accepted.push(target);
    }
    if(controls.length>=50)break;
 }
 return {facts,controls,close:accepted.length===1?accepted[0]:null};
}"""


def inspect_promo(page,guard,job,allow_close=False):
    from modern_map_reader import chart_box,position_chart
    from modern_map_surface import _INSPECT
    guard()
    with position_chart(page,guard) as box:
        guard()
        scan=page.evaluate_handle(_INSPECT,list(box))
        results=scan.evaluate_handle(ACTIONS)
        try:
            out=results.evaluate('s=>({facts:s.facts,controls:s.controls,unique_named_close:!!s.close})')
            out['recovery_clicked']=False
            if allow_close and out['unique_named_close'] and out['facts']['cards']==1 and not out['facts']['unknown']:
                control=results.get_property('close').as_element()
                if control:
                    try:
                        guard()
                        control.click(timeout=1800)
                        guard()
                        verify=page.evaluate_handle(_INSPECT,list(box))
                        try:out['after']=verify.evaluate('s=>s.facts')
                        finally:verify.dispose()
                        out['recovery_clicked']=True
                    finally:control.dispose()
            return out
        finally:
            results.dispose();scan.dispose()


def observe_failed(page,guard,job,extra,record,result,err):
    """Perform precise bounded checks on the still-current document. No login, new tab, or navigation."""
    from market_failure import diagnose
    from modern_map_reader import map_access_budget
    from modern_map_overview import after_read_failure
    doc=page.evaluate_handle('()=>document')
    def same():
        if page.is_closed() or not doc.evaluate('d=>d===document'):raise ValueError('diagnostic_document_changed')
        guard()
    try:
        with map_access_budget(35):
            same()
            start=time.monotonic()
            result['live_diagnostic_eligible']=True
            # See if the known normal in-page close was present after a confirmed obstruction.
            obstruction=next((v for v in reversed(extra.get('stages',[])) if v.get('name')=='chart_obstruction'),{})
            once=ROOT/'named_promo_recovery.once'
            possible=bool(obstruction.get('cards')==1 and obstruction.get('covered') and
                        not obstruction.get('unknown') and not obstruction.get('close_attempts') and not once.exists())
            if obstruction.get('covered') or obstruction.get('unknown'):
                frame=inspect_promo(page,same,job,allow_close=possible)
                record('stage',{'name':'failed_chart_affordances','status':'observed','elapsed_ms':round((time.monotonic()-start)*1000),**frame})
                if frame['recovery_clicked']:
                    once.touch(mode=0o600,exist_ok=False)
                    after=frame.get('after',{})
                    if not after.get('covered') and not after.get('unknown'):
                        after_read_failure(page,same,record)
                        return True
            diagnose(page,same,extra,record,result)
            after_read_failure(page,same,record)
            return False
    finally:doc.dispose()
