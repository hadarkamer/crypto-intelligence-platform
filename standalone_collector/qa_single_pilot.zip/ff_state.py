"""Scoped Firefox cookie view and validated protected account receipt."""
import hashlib
import hmac
import re
from urllib.parse import urlsplit
from session_state import validate_state,SessionStateError

def snapshot(context,page,previous=None):
    u=urlsplit(page.url)
    if (u.scheme!='https' or u.hostname not in ('coinglass.com','www.coinglass.com') or
            u.username or u.password or u.port not in (None,443)):
        raise SessionStateError('session_snapshot_failed')
    urls={'https://'+u.hostname+u.path,'https://www.coinglass.com/',
          'https://capi.coinglass.com/coin-community/api/userapi/info',
          'https://fapi.coinglass.com/coin-community/api/user/web/session'}
    if previous:
        for cookie in validate_state(previous)['cookies']:
            urls.add('https://'+cookie['domain'].lstrip('.')+cookie['path'])
    items=context.cookies(sorted(urls))
    if any(item.get('partitionKey') for item in items):
        raise SessionStateError('session_cookie_attributes_unsupported')
    return validate_state({'cookies':items,'origins':[]})

def account_identity(data,digest):
    if not isinstance(data,dict):return 'unknown'
    # Only the authenticated account object, never referral, contacts, or user-supplied display text.
    candidates=[data]+[data[k] for k in ('user','userInfo','account','profile') if isinstance(data.get(k),dict)]
    outcomes=set()
    for record in candidates:
        for field in ('email','emailAddress','userEmail','user_email','loginEmail'):
            value=record.get(field)
            if not isinstance(value,str):continue
            address=value.strip().lower()
            if len(address)>320 or not re.fullmatch(r"[a-z0-9_+%-]+(?:[.][a-z0-9_+%-]+)*@[a-z0-9-]+(?:[.][a-z0-9-]+)+",address):continue
            matches=hmac.compare_digest(hashlib.sha256(address.encode()).hexdigest(),digest)
            outcomes.add('match' if matches else 'different')
    return 'different' if 'different' in outcomes else 'match' if 'match' in outcomes else 'unknown'

def account_match(data,digest):
    return account_identity(data,digest)=='match'

def proof_decision(receipt,signals,submitted,blocked):
    if blocked or not submitted or receipt.get('different_account') or receipt.get('principal_binding')=='different' or receipt.get('login_response_class'):
        return 'stop'
    statuses=receipt.get('actual_login_post_statuses',[])
    if receipt.get('actual_login_post_requests')!=1 or len(statuses)!=1 or not 200<=statuses[0]<300 or receipt.get('post_without_response'):
        return 'stop'
    envelope=receipt.get('authenticated_account_envelope') is True
    exact=(receipt.get('exact_account_match') is True or receipt.get('principal_binding')=='linked')
    if exact and (envelope or signals.get('logout_visible') is True):return 'dedicated'
    return 'map_only' if envelope else 'stop'

def is_login(key,native=None):
    if not key:return False
    if key==native:return True
    parts=key[1].lower().strip('/').split('/')
    return any(re.fullmatch(r'(?:login|signin|sign-in|sign_in)(?:by|with|using)?(?:email|password|mail|account)?|(?:email|password|account)(?:login|signin)|(?:login|signin)-?(?:by-?)?(?:email|password|mail)',p) for p in parts)

def wire_type():
    from wire_evidence import WireEvidence,_endpoint
    class ConfirmedWire(WireEvidence):
        def __init__(self,c,digest,binding=None):
            from principals import Binding
            self.binding=binding or Binding();self.after_login_accounts=set()
            super().__init__(c)
            self.digest=digest;self.identity=False;self.different=False;self.official_posts=0;self.routes_seen=set();self.login_responses=[];self.provider_error=None
        def request(self,q):
            if self.armed and self.posts and q.method=='GET' and _endpoint(q.url)==('capi.coinglass.com','/coin-community/api/userapi/info'):
                self.after_login_accounts.add(q)
            if self.armed and q.method=='POST':
                key=_endpoint(q.url)
                if key:self.official_posts+=1
                if is_login(key,self.native_action):
                    self.pending.add(q);self.posts+=1
                    if re.fullmatch(r'/(?:[a-z][a-z0-9-]{0,30}/){0,8}[a-z][a-z0-9-]{0,30}',key[1]):
                        self.routes_seen.add((key[0],key[1]) if all(s in {'coin-community','api','user','userapi','web','v1','v2','auth','account','email','password','mail','by','with'} or is_login((key[0],s)) for s in key[1].split('/') if s) else (key[0],'recognized_auth_route'))
        def response(self,res):
            if self.armed and res.request in self.pending:self.login_responses.append(res)
            if _endpoint(res.url)==('capi.coinglass.com','/coin-community/api/userapi/info') and not self.observe_account_only and res.request not in self.after_login_accounts:return
            super().response(res)
        def account_envelope(self):
            for reply in self.login_responses:
                try:
                    if reply.status==429:self.provider_error='login_rate_limited'
                    j=reply.json()
                    if 200<=reply.status<300 and _endpoint(reply.url)==('capi.coinglass.com','/coin-community/api/user/login'):
                        self.binding.observe_login(j,self.digest)
                    if not isinstance(j,dict) or j.get('success') is True:continue
                    if j.get('success') is False:self.provider_error=self.provider_error or 'login_provider_rejected'
                    msg=' '.join(v[:300] for k in ('message','msg','error','error_description') if isinstance(v:=j.get(k),str))
                    cases=[('login_captcha_required',r'captcha|verify (?:that )?you are human'),('login_verification_required',r'verification code|two.factor|one.time code'),('login_rate_limited',r'too many|rate limit'),('login_credentials_rejected',r'incorrect (?:email|password|credentials)|(?:email|password|credentials).{0,15}(?:wrong|invalid|incorrect)|invalid (?:email|password|credentials)')]
                    for code,pattern in cases:
                        if re.search(pattern,msg,re.I):self.provider_error=code;break
                except Exception:pass
            self.login_responses.clear()
            for reply in self.account_responses:
                try:
                    obj=reply.json()
                    if isinstance(obj,dict) and obj.get('success') is True and obj.get('data'):
                        self.api_accepted=True
                        self.binding.observe_current(obj['data'])
                        identity=account_identity(obj['data'],self.digest)
                        self.identity |= identity=='match'
                        self.different |= identity=='different'
                except Exception:pass
            self.account_responses.clear()
            return self.api_accepted
        def public(self):
            result=super().public()
            result.update(principal_binding=self.binding.link(),explicit_login_acceptance=self.binding.accepted,different_account=self.different or self.binding.login_email_different,exact_account_match=self.identity,official_post_count=self.official_posts,
                          observed_login_routes=sorted(self.routes_seen),login_response_class=self.provider_error)
            return result
    return ConfirmedWire
