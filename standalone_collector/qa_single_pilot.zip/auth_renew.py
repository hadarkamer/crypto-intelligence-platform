"""One official renewal following an explicit access gate in a restored dedicated session."""
from hashlib import sha256
from pathlib import Path
import os
import time

def renew(browser,db,key,email,password,job,result,meter):
    from single_source import CONTEXT,ROOT,PREVIOUS
    from dedicated_login_form import submit_official_login,_before_submit_blocker
    from dedicated_map_flow import FORM_REASONS
    from account_large_object import save
    from dedicated_auth_state import DedicatedSessionStore
    from ff_state import wire_type,is_login,snapshot
    from wire_evidence import _endpoint
    from principals import Binding
    from pub import ADS
    if not password:raise ValueError('dedicated_configuration_missing')
    store=DedicatedSessionStore(db,key,email)
    # An active challenge, provider cooldown or an independent job is never superseded.
    prev=db.execute("""SELECT i.id FROM collector_private.coinglass_dedicated_auth i
       JOIN collector_private.coinglass_dedicated_auth_jobs j ON j.incident_id=i.id
       WHERE j.job_id=%s AND i.slot=%s AND i.phase='blocked' AND i.reason='auth_unconfirmed'
       AND i.attempts=1 AND i.owner_job IS NULL AND i.owner_revision IS NULL
       AND i.superseded_by IS NULL AND (i.retry_after IS NULL OR i.retry_after<=clock_timestamp())
       AND NOT EXISTS (SELECT 1 FROM collector_private.coinglass_dedicated_auth_jobs z
              WHERE z.incident_id=i.id AND z.job_id<>j.job_id)""",(PREVIOUS,store.slot)).fetchone()
    if prev:store.acknowledge_remediation(prev['id'])
    lease=store.begin(job,allow_initial_probe=True)
    try:
        if store.source_cooldown(lease)['code']!='allowed':raise ValueError('source_rate_limited')
        ballot=store.auth_start(lease)
        if ballot['code']!='allowed':raise ValueError(ballot['code'])
        incident=ballot['incident_id']
        ctx=browser.new_context(**CONTEXT)
        meter.attach(ctx)
        ctx.route(ADS,lambda route:route.abort())
        page=ctx.new_page()
        wire=wire_type()(ctx,sha256(email.strip().lower().encode()).hexdigest(),Binding(True))
        wire.attach()
        admitted=False
        def route_once(route):
            nonlocal admitted
            if route.request.method=='POST' and is_login(_endpoint(route.request.url),wire.native_action):
                if not wire.armed or admitted:
                    return route.abort()
                admitted=True
            route.fallback()
        ctx.route('**/*',route_once)
        def reserve():
            with (ROOT/'credential-submission-reservation').open('x') as p:p.write(job)
            store.auth_submit(lease,incident);wire.arm_after_durable_fence(page.url)
            return True
        result['renewal_attempt']=1
        answer=submit_official_login(page,timeout_ms=35000,credentials=lambda:(email,password),before_submit=reserve)
        reason=FORM_REASONS.get(answer.code)
        until=time.monotonic()+8
        while answer.submitted and not reason and time.monotonic()<until:
            wire.account_envelope()
            reason=wire.provider_error or _before_submit_blocker(page)
            if wire.different or wire.binding.link()=='different':raise ValueError('conflicting_account')
            if wire.api_accepted and wire.binding.accepted:break
            page.wait_for_timeout(110)
        wire.account_envelope();result['actual_login_posts']=wire.posts
        meter.count('login_submit',wire.posts)
        if reason or not (wire.posts==1 and len(wire.statuses)==1 and 200<=wire.statuses[0]<300
                 and wire.api_accepted and wire.binding.accepted and not wire.different and wire.binding.link()!='different'):
            code=FORM_REASONS.get(reason,reason) if reason else 'auth_unconfirmed'
            try:store.auth_result(lease,incident,code,answer.retry_after_seconds)
            except Exception:pass
            raise ValueError(code)
        save(db,key,store.slot,job,snapshot(ctx,page),account_verified=True)
        result['renewed_owner_only_state']=True
        return ctx,page,wire
    finally:
        store.complete(lease,'unconfirmed')
