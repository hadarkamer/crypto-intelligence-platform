"""One private, restored Firefox collection initiated by the native application's accepted job."""
import base64
from contextlib import contextmanager
from hashlib import sha256
import hmac
from io import BytesIO
import json
import os
from pathlib import Path
import re
import sys
import time
import traceback

from pilot_telemetry import PilotTelemetry

ROOT = Path('/tmp/cg-budget')
PREVIOUS = 'aa3ab31f-828f-4465-95da-60a462e802a5'
TARGET = 'https://www.coinglass.com/LiquidationHeatMap/BTC?mode=coin'
CONTEXT = dict(locale='en-US', timezone_id='UTC', color_scheme='dark',
               device_scale_factor=1, viewport={'width':1440,'height':1280})


def atomic(name, data):
    import tempfile
    with tempfile.NamedTemporaryFile(dir=ROOT,delete=False) as output:
        output.write(data)
        output.flush()
        os.fsync(output.fileno())
        stage=output.name
    os.replace(stage,ROOT/name)


def put(name, data):
    atomic(name, json.dumps(data,allow_nan=False,separators=(',',':')).encode())


def failure(error):
    def word(val):
        return val if isinstance(val,str) and re.fullmatch(r'[a-zA-Z0-9_]{1,85}',val) else None
    return {'type':word(type(error).__name__), 'code':word(getattr(error,'code',None)) or word(str(error)),
            'reason':word(getattr(error,'reason',None)),
            'frames':[[Path(f.filename).name,f.name,f.lineno] for f in traceback.extract_tb(error.__traceback__)[-7:]]}


def retain_supplement(db,key,job):
    """Keep the market-only partial checkpoint, including the plot, under the existing owner-only LOs."""
    from qa_aesgcm import AESGCM
    from market_vault import _owner_only
    info=ROOT/'market-supplement.json'
    if not info.is_file():return None
    raw=info.read_bytes()
    plot=ROOT/'chart-observation.png'
    image=plot.read_bytes() if plot.is_file() else b''
    if len(raw)>2*1024**2 or len(image)>4*1024**2:raise ValueError('supplement_too_large')
    body=len(raw).to_bytes(4,'big') + raw + image
    digest=sha256(body).hexdigest()
    tag=b'coinglass.qa.single-market-supplement.v1\0'
    aad=tag+job.encode()+b'\0'+digest.encode()
    codec=AESGCM(hmac.digest(key,tag,'sha256'))
    oid=0x80000000 | int.from_bytes(hmac.digest(key,aad,'sha256')[:4],'big')
    with db.transaction():
        if not _owner_only(db,oid):
            nonce=os.urandom(12)
            sealed=nonce+codec.encrypt(nonce,body,aad)
            result=db.execute('SELECT pg_catalog.lo_from_bytea(%s::oid,%s::bytea) AS oid',(oid,sealed)).fetchone()['oid']
            if oid!=result or not _owner_only(db,oid):raise ValueError('owner_check_failed')
        recovered=bytes(db.execute('SELECT pg_catalog.lo_get(%s::oid,0,%s) AS data',(oid,len(body)+29)).fetchone()['data'])
        if not hmac.compare_digest(body,codec.decrypt(recovered[:12],recovered[12:],aad)):
            raise ValueError('supplement_readback_failed')
    return dict(oid=oid,sha256=digest,bytes=len(body),png_bytes=len(image),private_readback=True)


def source(job, meter, result):
    from psycopg import connect
    from psycopg.rows import dict_row
    from account_large_object import load,_id
    from session_state import WORK_LOCK
    from dedicated_auth_state import account_slot
    from ff_state import wire_type,is_login
    from wire_evidence import _endpoint
    from modern_map_reader import open_verified_map,read_selected_map,map_access_budget
    from model1_execution import capture_operation
    from dedicated_map_flow import PROTECTED_PROBE,guard_surface
    from market_vault import retain_verified
    from retained_evidence import pack,retain,checked_png
    from playwright.sync_api import sync_playwright
    from auth_renew import renew
    from active_diagnostic import observe_failed
    from end_fence import verify_end

    dsn,keytext,email,password=[os.environ.pop(k,None) for k in
        ('DATABASE_URL','COINGLASS_SESSION_KEY','COINGLASS_LOGIN_EMAIL','COINGLASS_LOGIN_PASSWORD')]
    if not dsn or not keytext or not email:raise ValueError('missing_server_configuration')
    key=base64.b64decode(keytext,validate=True)
    digest=sha256(email.strip().lower().encode()).hexdigest()
    extra={'job_id':job,'source_time':None,'overview':None,'hover':[],'stages':[]}
    with connect(dsn,autocommit=True,connect_timeout=5,row_factory=dict_row) as db:
        meter.count('db_connections')
        if not db.execute('SELECT pg_try_advisory_lock(%s) AS ok',(WORK_LOCK,)).fetchone()['ok']:
            raise ValueError('worker_busy')
        with meter.phase('restore'):
            result['stage']='restore'
            rows=db.execute("""SELECT i.slot FROM collector_private.coinglass_dedicated_auth i JOIN
              collector_private.coinglass_dedicated_auth_jobs j ON j.incident_id=i.id WHERE j.job_id=%s""",(PREVIOUS,)).fetchall()
            slot=account_slot(key,email)
            if len(rows)!=1 or not hmac.compare_digest(rows[0]['slot'],slot):raise ValueError('restored_account_binding_mismatch')
            restored=load(db,key,slot,PREVIOUS,_id(key,slot,PREVIOUS))
            result['restored_owner_only_state']=True
        try:
            with sync_playwright() as pw:
                result['stage']='browser'
                with meter.phase('browser'):
                    browser=pw.firefox.launch(headless=True,timeout=20000,env={k:os.environ[k] for k in
                        ('HOME','LANG','PATH','LD_LIBRARY_PATH') if k in os.environ})
                    meter.count('browser_launch')
                try:
                    context=browser.new_context(storage_state=restored,**CONTEXT)
                    del restored
                    meter.attach(context)
                    wire=wire_type()(context,digest)
                    wire.observe_account_only=True
                    wire.attach()
                    def readonly(route):
                        req=route.request
                        if req.method not in ('GET','HEAD','OPTIONS'):
                            if is_login(_endpoint(req.url),('www.coinglass.com','/login')):result['unsolicited_login_blocked']=True
                            route.abort()
                        else:route.fallback()
                    from pub import ADS
                    context.route(ADS,lambda route:route.abort())
                    context.route('**/*',readonly)
                    page=context.new_page()
                    def guard():
                        guard_surface(page,PROTECTED_PROBE)
                        wire.account_envelope()
                        if wire.different or wire.provider_error:raise ValueError('account_mismatch_or_denial')
                    def opening():
                        with meter.phase('map'),map_access_budget(65):
                            return open_verified_map(page,'BTC',1,'12H',guard=guard)
                    result['stage']='map_open'
                    try:raw=opening()
                    except Exception as err:
                        if getattr(err,'code',None)!='source_login_required':raise
                        # Ask the official UI again at the actually selected target before touching the password.
                        try:guard_surface(page,PROTECTED_PROBE)
                        except Exception as verified_gate:
                            if getattr(verified_gate,'code',None)!='source_login_required':raise err
                        else:raise err
                        context.close()
                        with meter.phase('login'):
                            context,page,wire=renew(browser,db,key,email,password,job,result,meter)
                        password=None
                        raw=opening()
                    result.update(protected_map=True,source_identity=['BTC',1,'Coin','12H'],access_metrics=raw)
                    result['account_http']=wire.account_reply_status
                    result['account_positive']=wire.account_envelope()
                    if wire.different or wire.provider_error:raise ValueError('account_mismatch_or_denial')
                    def record(kind,value):
                        if kind=='png':
                            checked_png(value);atomic('chart-observation.png',value)
                        elif kind=='overview':
                            extra['overview']=value
                            extra['source_time']=value.get('source_time')
                        elif kind in ('hover','stage'):
                            values=extra['hover' if kind=='hover' else 'stages']
                            if len(values)<260:values.append(value)
                        else:return
                        put('market-supplement.json',extra)
                        if kind=='stage':
                            label=value.get('name','')
                            ms=value.get('elapsed_ms')
                            if type(ms) in (int,float) and 0<=ms<=210000:
                                end=time.monotonic()
                                meter.spans.append(('reader.'+label,end-ms/1000,end))
                            if label in ('read_market_overview','recheck_market_update'):meter.count('dom_batch')
                            if label=='read_hover':
                                meter.count('hover_try')
                                if value.get('status')=='ok':meter.count('hover_ok')
                            if label.startswith('measure_'):
                                meter.count('measure_try')
                                if value.get('status')=='ok':meter.count('measure_ok')
                            # Stage names and typed numerical conditions are safe for private service logs.
                            print('QA_READER',value,flush=True)
                    result['stage']='map_read'
                    bound=page.evaluate_handle('()=>document')
                    def selected():
                        if (page.is_closed() or page.url!=TARGET or not bound.evaluate('d=>d===document')):
                            raise ValueError('selected_document_replaced')
                        guard()
                    def capture_checked(crop):
                        snap=read_selected_map(page,'BTC',1,'12H',crop,guard=selected,observe=record)
                        extra['candidate_before_end_verification']=snap
                        put('market-supplement.json',extra)
                        result['end_fence']=verify_end(page,snap,extra['overview'],selected,record,extra['stages'])
                        if result['end_fence'].get('status')!='verified':raise ValueError('end_fence_not_verified')
                        extra['end_fence']=result['end_fence']
                        extra.pop('candidate_before_end_verification',None)
                        put('market-supplement.json',extra)
                        return snap
                    with BytesIO() as crop,map_access_budget(245),capture_operation('capture'):
                        try:
                            try:snapshot=capture_checked(crop)
                            except Exception as error:
                                result['reader_failure']=failure(error)
                                if getattr(error,'code',None) in ('source_login_required','source_rate_limited','auth_challenge','auth_code_required'):
                                    raise
                                try:
                                    redressed=observe_failed(page,selected,job,extra,record,result,error)
                                except Exception as diagnostic_error:
                                    result['diagnostic_failure']=failure(diagnostic_error)
                                    redressed=False
                                before=extra.get('source_time')
                                post=next((v.get('post_failure_source_time') for v in reversed(extra.get('stages',[]))
                                     if v.get('name')=='post_failure_market_observation' and v.get('status')=='observed'),None)
                                rolled=bool(before and post and before!=post)
                                if not (redressed or rolled):
                                    raise
                                if not before:raise ValueError('unavailable_recovery_update')
                                selected()
                                result['prior_partial_vault']=retain_supplement(db,key,job)
                                result['bounded_recovery']='new_source_update' if rolled else 'normal_in_page_close'
                                result['previous_source_time']=before
                                result['observed_new_source_time']=post if rolled else None
                                meter.count('retry')
                                extra.clear()
                                extra.update(job_id=job,source_time=None,overview=None,hover=[],stages=[])
                                # Keep the original partial in the encrypted vault. The new pass has independent bytes and members.
                                (ROOT/'chart-observation.png').unlink(missing_ok=True)
                                put('market-supplement.json',extra)
                                crop.seek(0);crop.truncate(0)
                                try:snapshot=capture_checked(crop)
                                except Exception as last:
                                    result['retry_failure']=failure(last)
                                    from modern_map_overview import after_read_failure
                                    after_read_failure(page,selected,record)
                                    raise
                                expected=post if rolled else before
                                if snapshot['source_time']!=expected:raise ValueError('changed_source_during_recovery')
                            image=crop.getvalue()
                        finally:bound.dispose()
                    if not extra['source_time'] or extra['source_time']!=snapshot['source_time']:raise ValueError('overview_update_mismatch')
                    result['stage']='source_save'
                    with meter.phase('source_save'):
                        blob=pack(snapshot,image,job)
                        market_digest=retain(job,blob)
                        ref=retain_verified(db,key,job,market_digest)
                        result['market_vault']=ref
                        meter.count('source_bytes',len(blob))
                        result['chart_sha256']=sha256(image).hexdigest()
                        atomic('chart-final.png',image)
                        put('snapshot.json',snapshot)
                        result['numeric_read']='verified'
                finally:
                    with meter.phase('close'):
                        browser.close();meter.count('browser_close')
        finally:
            with meter.phase('source_save'):
                result['supplement_vault']=retain_supplement(db,key,job)


def main():
    job=sys.argv[1]
    result=dict(job_id=job,protected_map=False,actual_login_posts=0)
    with PilotTelemetry() as meter, meter.browser_actions():
        try:source(job,meter,result)
        except Exception as exc:result['failure']=failure(exc)
    put('source-metrics.json',meter.report())
    put('source-receipt.json',result)
    print('QA_SOURCE',job,result.get('stage'),result.get('numeric_read'),result.get('failure'),flush=True)


if __name__=='__main__':
    main()
