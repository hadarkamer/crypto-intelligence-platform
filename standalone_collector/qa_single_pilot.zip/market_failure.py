"""Bounded forensic observation of the same selected market page. No navigation or account data."""
import re
import time

def diagnose(page,guard,extra,record,result):
    from modern_map_reader import chart_box,position_chart,PAINT
    from modern_map_overview import overview
    from market_capture import capture
    guard()
    exact=page.url=='https://www.coinglass.com/LiquidationHeatMap/BTC?mode=coin'
    if not exact:return
    if not extra.get('overview'):
        record('overview',overview(page))
    with position_chart(page,guard) as box:
        guard()
        diagnostic={'chart_box':list(box),'viewport':page.viewport_size}
        raw,img=capture(page)
        diagnostic['chart_surface']={k:raw[k] for k in ('geometry','capture_status','settings','shape') if k in raw}
        if img and not (__import__('pathlib').Path('/tmp/cg-budget/chart-observation.png')).is_file():record('png',img)
        last=(extra.get('hover') or [{}])[-1]
        if last.get('expected')=='bottom_crosshair_time_at_pointer' and isinstance(last.get('x'),int) and isinstance(last.get('y'),int):
            x,y=last['x'],last['y'];left,top,w,h=box
            if left<=x<left+w and top<=y<top+h:
                # Record only chart-painted numeric and timestamp labels at each physical cursor position.
                diagnostic['pointer_axis']=[]
                for label,xx,yy in [('off',max(0,left-2),max(0,top-2)),('prior',max(left+1,x-max(36,w//5)),y),('latest',x,y)]:
                    guard()
                    paint=page.evaluate_handle(PAINT,list(box))
                    try:
                        page.mouse.move(xx,yy)
                        page.evaluate('()=>new Promise(done=>requestAnimationFrame(()=>requestAnimationFrame(done)))')
                        marks=paint.evaluate('v=>v.labels')
                        ticks=[[str(t),round(mx),round(my)] for t,mx,my,*_ in marks
                           if re.fullmatch(r'(?:(?:\d{1,2}/\d{1,2} )?\d{2}:\d{2}|\d[\d,.]{0,14})',str(t))]
                        seen=list(dict.fromkeys(tuple(a) for a in ticks))
                        diagnostic['pointer_axis'].append({'kind':label,'pointer':[xx,yy],'marks':list(seen)[:700]})
                    finally:
                        paint.evaluate('v=>v.restore()');paint.dispose()
        result['market_diagnostic']=diagnostic
        extra['diagnostic']=diagnostic
        record('stage',{'name':'diagnose_failed_market_read','status':'partial','elapsed_ms':0})
        print('QA_DIAGNOSTIC',diagnostic['chart_surface'],[len(v['marks']) for v in diagnostic.get('pointer_axis',[])],flush=True)
