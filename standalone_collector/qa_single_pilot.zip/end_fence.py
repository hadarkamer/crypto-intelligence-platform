"""QA-only closing observation of one already selected, guarded BTC/M1/12H chart."""
from datetime import datetime
from decimal import Decimal
from io import BytesIO
from math import ceil, floor
from time import monotonic

from PIL import Image
from modern_map_axis import axis_marks, axis_scale
from modern_map_cells import merge_cells
from modern_map_evidence import equivalent, iso, number, sample_groups, source_clock, validate_groups
from modern_map_overview import overview
from modern_map_reader import (PAINT, choice, clear_cookie_notice, dark_bounds, limited_timeout, map_access_budget,
                               map_url, measure_box, option_control, position_chart, protected_clip,
                               read_paint, select_choice, symbol_control)
from modern_map_surface import _INSPECT
from modern_map_tooltip import member_for, read_tooltip
from model1_execution import StageFailure


class EndFenceError(RuntimeError):
    code='source_not_readable'
    def __init__(self,reason):
        self.reason=reason
        super().__init__(reason)


def require(value,reason):
    if not value:
        raise EndFenceError(reason)


_FIELDS=('source_time','raw_total','raw_above_total','raw_below_total','raw_price_step','raw_column_period',
         'raw_largest_value','sidebar_levels')


def matching_end_market(prior, end):
    require(all(prior.get(k)==end.get(k) for k in _FIELDS),'end_market_observation_changed')
    require(not ({'sidebar_shape','sidebar_levels','source_time'} & set(end.get('ambiguous_fields',[]))),
            'end_market_fields_ambiguous')


def bind_groups(snapshot, runs, step):
    """Compare every independently selected eligible price bin, not just sidebar membership."""
    ref=number(snapshot['raw_last_price'])[0]
    validate_groups(snapshot['groups'],ref,snapshot['raw_price_step'],snapshot['raw_above_total'],snapshot['raw_below_total'])
    expected=sorted(snapshot['groups'],key=lambda group:number(group['members'][0]['raw_price'])[0])
    require(len(expected)==len(runs),'end_cluster_count_changed')
    bound=[]
    for original,(colour,rows) in zip(expected,runs):
        require(original['colour']==colour and len(original['members'])==len(rows),'end_cluster_shape_changed')
        for member,row in zip(original['members'],rows):
            require(original['side']==row['side'] and abs(float(number(member['raw_price'])[0])-row['price'])<=step*.35,
                    'end_cluster_bin_changed')
            bound.append((row,member,colour))
    return bound


def displayed_equal(first,second,reason):
    try:
        equivalent(first,[second])
    except StageFailure:
        raise EndFenceError(reason) from None


def _verify(page,snap,start,guard,observe):
    require((snap.get('symbol'),snap.get('heatmap_model'),snap.get('timeframe'),snap.get('mode'),snap.get('lens'),
             snap.get('palette'),snap.get('theme'),snap.get('intensity'),snap.get('count'))==
            ('BTC',1,'12H','Coin','Heat','Viridis','dark',[0,100],'Right edge'),'end_wrong_target')
    require(snap.get('source_time')==snap.get('source_time_after')==start.get('source_time') and
            snap.get('column_time')==snap.get('column_time_after'),'end_initial_stamps_incomplete')
    step=float(number(snap['raw_price_step'])[0])
    column=datetime.fromisoformat(snap['column_time'].replace('Z','+00:00'))
    update=datetime.fromisoformat(snap['source_time'].replace('Z','+00:00'))

    def safe():
        limited_timeout(4000)
        guard()
        require(page.url==map_url('BTC') and not page.is_closed(),'end_map_not_current')
        clear_cookie_notice(page)

    def identity():
        safe()
        require(choice(page,'Coin') and choice(page,'Model 1') and choice(page,'Pan') and
                symbol_control(page,'BTC') and option_control(page,'Range').inner_text().strip()=='12 hour' and
                option_control(page,'Layout').inner_text().strip()=='Single chart' and
                option_control(page,'Lens').inner_text().strip()=='Heat' and
                ' '.join(option_control(page,'Colours').inner_text().split()) in ('Viridis','Viridis Default'),
                'end_settings_changed')

    identity()
    with position_chart(page,safe) as box:
        sx,sy,w,h=box
        page.mouse.move(max(0,sx-2),max(0,sy-2))
        surface=page.evaluate_handle(_INSPECT,list(box))
        try:
            facts=surface.evaluate('s=>s.facts')
        finally:surface.dispose()
        require(not facts['covered'] and not facts['unknown'],'end_chart_obstructed')
        raw=protected_clip(page,dict(x=sx,y=sy,width=w,height=h),safe)
        with Image.open(BytesIO(raw)) as original:
            require(original.size==(w,h),'end_chart_clipped')
            frame=original.convert('RGB')
        try:
            vis=(0,0,w,h)
            bounds=dark_bounds(frame,vis)
            left,top,right,bottom=bounds
            absolute=(left+sx,top+sy,right+sx,bottom+sy)
            y=sy+(top+bottom)//2
            def stamps(x):
                safe()
                return read_paint(page,box,x,y)
            def observe_last():
                stamp,labels=stamps(sx+right-1)
                require(iso(source_clock(stamp,update,column=True))==snap['column_time'],'end_latest_column_changed')
                return labels

            # Start with ordinary, visible numeric ticks. Moving crosshair is
            # necessary only when the renderer supplies the labels on canvas.
            def calibrate(prior,current):
                marks=axis_marks(page,box,prior,current)
                local_marks=[(r,x-sx,yy-sy) for r,x,yy,*_ in marks]
                return axis_scale(frame,vis,bounds,local_marks)
            scale=calibrate([],[])
            measurements=0
            if scale is None:
                _,prior=stamps(sx+left+(right-left)*.72)
                current=observe_last()
                scale=calibrate(prior,current)
            if scale is None:
                # Need the source's own numerical reference and price domain.
                safe()
                last,total,_,low,high=measure_box(page,absolute,sy+top+.2,sy+bottom-.2)
                measurements+=1
                displayed_equal(start['raw_total'],total,'end_domain_total_changed')
                ref=number(last)[0]
                require(0<low<ref<high,'end_price_domain_missing')
                def where(price):
                    return bottom-.2-(price-float(low))*(bottom-top-.4)/float(high-low)
                select_choice(page,'Pan')
                method='measure'
            else:
                last,where=scale
                method='displayed_axis'
            require(number(last)[0]==number(snap['raw_last_price'])[0],'end_reference_price_changed')
            end=overview(page)
            matching_end_market(start,end)
            require(end['sidebar_levels'],'end_grid_anchor_missing')
            anchor=float(number(end['sidebar_levels'][0]['raw_price'])[0])
            height,runs=sample_groups(frame,bounds,1,anchor,step,where,float(number(last)[0]))
            bins=floor((where(anchor)-top)/height)-ceil((where(anchor)-bottom)/height)+1
            members=bind_groups(snap,runs,step)
            require(len(members)<=bins<=1601,'end_grid_extent_invalid')
            by_price={number(r['raw_price'])[0]:r for r in end['sidebar_levels']}
            book={}
            receipts=[]
            hover_count=0
            useful_hover=False
            for row,member,colour in members:
                price=number(member['raw_price'])[0]
                side=by_price.get(price)
                if side is not None and end.get('raw_largest_value') and (
                        number(side['raw_value'],True)[0]==number(end['raw_largest_value'],True)[0]):
                    checked=side['raw_value'];origin='sidebar_and_source_maximum'
                else:
                    cell=member_for(book,row,step)
                    if cell is None and (hover_count<2 or useful_hover):
                        select_choice(page,'Pan')
                        safe()
                        event=read_tooltip(page,box,absolute,column,sx+right-1,sy+row['y'],PAINT)
                        hover_count+=1
                        stats=merge_cells(book,event['rows'],column.strftime('%m/%d %H:%M'),snap['raw_price_step'])
                        useful_hover=useful_hover or bool(stats['accepted'])
                        cell=member_for(book,row,step)
                    if cell is None:
                        safe()
                        ref,total,cell,_,_=measure_box(page,absolute,max(sy+top,sy+row['y']-height*.48),
                                                       min(sy+bottom,sy+row['y']+height*.48))
                        measurements+=1
                        require(number(ref)[0]==number(last)[0],'end_reference_price_changed')
                        displayed_equal(total,cell['raw_value'],'end_measure_spans_multiple_bins')
                        origin='measure'
                    else:origin='native_hover'
                    require(number(cell['raw_price'])[0]==price,'end_number_bound_to_different_price')
                    checked=cell['raw_value']
                displayed_equal(member['raw_value'],checked,'end_cluster_amount_changed')
                receipts.append(dict(raw_price=member['raw_price'],raw_value=checked,side=row['side'],colour=colour,method=origin))
                observe('stage',dict(name='end_bin_observed',status='ok',**receipts[-1]))
            if not choice(page,'Pan'):
                select_choice(page,'Pan')
            # A later update may occur during the closing numerical checks.
            observe_last()
            final=overview(page)
            matching_end_market(start,final)
            identity()
            return dict(status='verified',source_time=final['source_time'],column_time=snap['column_time'],
                        raw_reference_price=last,reference_method=method,native_price_bins_inspected=bins,
                        significant_bins_verified=len(members),significant_groups_verified=len(runs),
                        hover_actions=hover_count,measure_actions=measurements,verified_members=receipts)
        finally:frame.close()


def verify_end(page,snapshot,overview_before,guard,observe,events=None):
    """Calls official UI operations only on the open map; bound the entire closing observation."""
    began=monotonic()
    try:
        with map_access_budget(limited_timeout(40000)/1000):
            result=_verify(page,snapshot,overview_before,guard,observe)
    except Exception as error:
        observe('stage',dict(name='closing_map_verification',status='failed',elapsed_ms=round((monotonic()-began)*1000),
                             condition=getattr(error,'reason',None) or getattr(error,'code','end_observation_failed')))
        raise
    result['elapsed_ms']=round((monotonic()-began)*1000)
    observe('stage',dict(name='closing_map_verification',**result))
    return result
