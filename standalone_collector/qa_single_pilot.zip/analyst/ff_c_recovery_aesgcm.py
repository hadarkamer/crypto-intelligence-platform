from Crypto.Cipher import AES
class AESGCM:
    def __init__(self,key):
        if len(key)!=32:raise ValueError('invalid_key_length')
        self.key=key
    def encrypt(self,nonce,value,aad):
        cipher=AES.new(self.key,AES.MODE_GCM,nonce=nonce,mac_len=16)
        cipher.update(aad)
        body,tag=cipher.encrypt_and_digest(value)
        return body+tag
    def decrypt(self,nonce,value,aad):
        cipher=AES.new(self.key,AES.MODE_GCM,nonce=nonce,mac_len=16)
        cipher.update(aad)
        return cipher.decrypt_and_verify(value[:-16],value[-16:])
