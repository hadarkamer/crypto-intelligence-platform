"""Safe execution diagnostics and small-worker resource control.

Never logs raw browser/API errors, response bodies, cookies or profiles.
Only unrelated advertising/analytics hosts are excluded; CoinGlass, its assets,
authentication and challenge providers are not intercepted or bypassed.
"""
from __future__ import annotations
from contextlib import contextmanager
import json
import math
from pathlib import Path
import re
import time

CODES=frozenset({'evidence_store_failed','source_capture_failed','source_timeout','source_not_readable','source_login_required',
    'source_map_unavailable','source_navigation_changed','source_rate_limited',
    'auth_configuration_invalid','auth_challenge','auth_code_required','auth_rate_limited','auth_invalid_credentials',
    'auth_form_unavailable','auth_unconfirmed','auth_gate_after_verification','auth_retry_exhausted','auth_retry_pending',
    'auth_in_progress','auth_attempt_not_reserved','auth_protected_proof_required','auth_result_invalid',
    'session_conflict','state_revision_conflict','state_store_failed',
    'session_input_invalid','session_transport_failed','session_snapshot_failed','session_observation_failed',
    'screenshot_identity_mismatch','image_evidence_invalid','analysis_timeout',
    'analysis_incomplete','analysis_response_invalid','analysis_unauthorized',
    'analysis_rate_limited','analysis_quota_exceeded','analysis_http_error',
    'price_uncertain','zones_invalid','worker_crashed'})
VALIDATION_REASONS=frozenset(['invalid_positive_number', 'evidence_text_invalid', 'evidence_number_mismatch', 'axis_shape', 'axis_does_not_cover_price', 'level_list_shape', 'level_object', 'level_confidence', 'right_edge_missing', 'colour_or_shape', 'yellow_shape', 'green_shape', 'blue_intensity', 'level_outside_axis', 'point_count', 'point_outside_bounds', 'uncertainty_invalid', 'exact_price_not_verified', 'exact_point_bounds', 'axis_estimate_invalid', 'uncertainty_does_not_cover_bounds', 'price_precision', 'strength_score', 'side_invalid', 'side_conflicts_with_price'])
VALIDATION_REASONS=VALIDATION_REASONS | frozenset(['hover_analysis_shape', 'hover_deadline', 'hover_evidence_mismatch', 'hover_geometry_invalid', 'hover_geometry_missing', 'hover_number_invalid', 'hover_plot_clipped', 'hover_plot_not_found', 'hover_point_multiple_rows', 'hover_pool_binding', 'hover_pool_empty_gap', 'hover_pool_overlap_or_gap', 'hover_pool_rows_invalid', 'hover_pool_uncertain', 'hover_price_grid_gap', 'hover_range_single_row', 'hover_resolution_insufficient', 'hover_row_count', 'hover_row_order', 'hover_rows_merged', 'hover_snapshot_changed', 'hover_source_stale', 'hover_text_invalid', 'hover_time_invalid', 'hover_timezone_not_utc'])
VALIDATION_REASONS=VALIDATION_REASONS | frozenset(['hover_update_timeout', 'hover_candidates_unresolved', 'hover_candidate_missing', 'hover_candidate_disagreement', 'hover_cookie_overlay'])
VALIDATION_REASONS=VALIDATION_REASONS | frozenset(['hover_price_axis_changed', 'hover_price_axis_mismatch'])
VALIDATION_REASONS=VALIDATION_REASONS | {'map_shorts_amount_unreadable', 'map_longs_amount_unreadable'}
MARKET_CLIP_REASONS = {'map_viewport_unavailable', 'map_clip_missing', 'map_clip_outside_viewport',
                       'map_clip_size_mismatch'}
VALIDATION_REASONS = VALIDATION_REASONS | MARKET_CLIP_REASONS

VALIDATION_REASONS=VALIDATION_REASONS | frozenset(['hover_image_evidence_missing', 'hover_image_changed', 'hover_candidate_evidence_mismatch', 'hover_pool_not_visible'])
VALIDATION_REASONS=VALIDATION_REASONS | frozenset(['hover_candle_text_invalid', 'hover_candle_time_invalid', 'hover_candle_number_invalid', 'hover_candle_evidence_mismatch', 'hover_candle_time_mismatch', 'hover_candle_not_found', 'hover_candle_outside_axis', 'hover_candle_changed'])
STAGES=frozenset({'startup','capture','image_check','analysis','validation','saving'})
PHASES=frozenset({'capture','select_12h','select_24h','select_48h','model_selection',
    'symbol_selection','wait_for_chart','screenshot','navigation','browser_launch',
    'browser_context','source_session_setup','page_creation','overlay_dismissal',
    'timeframe_selection','legend_preparation','chart_geometry','render_settle',
    'context_close','browser_close','render_readiness','timeframe_trigger_lookup',
    'timeframe_open','timeframe_option_lookup','timeframe_select','timeframe_confirmation','hover_collection'})
KINDS=frozenset({'TimeoutError','TargetClosedError','Error','RuntimeError','ValueError',
    'MemoryError','OSError','FileNotFoundError','ReadTimeout','ConnectTimeout'})
AD_HOSTS=re.compile(r'^https?://(?:[a-zA-Z0-9-]+\.)*(?:doubleclick\.net|googlesyndication\.com|google-analytics\.com|googletagmanager\.com)/')
_current_stage='startup'
_usage=None
_analysis_facts={}
_capture_events=[]
_progress_path=None
_progress_started=None
_active_capture_phase=None
_progress_identity={}


def safe_progress(value):
    if not isinstance(value,dict) or value.get('format_version')!='execution-progress.v1':return None
    if not isinstance(value.get('stage'),str) or value['stage'] not in STAGES:return None
    elapsed=value.get('elapsed_seconds')
    if type(elapsed) not in (int,float) or not math.isfinite(elapsed) or not 0<=elapsed<=360:return None
    phase=value.get('capture_phase')
    out={'format_version':'execution-progress.v1','stage':value['stage'],
        'elapsed_seconds':elapsed,'capture_phase':phase if isinstance(phase,str) and phase in PHASES else None,
        'capture_operations':[]}
    if type(value.get('heatmap_model')) is int and value['heatmap_model'] in (1,2,3):
        out['heatmap_model']=value['heatmap_model']
    if isinstance(value.get('timeframe'),str) and value['timeframe'] in ('12H','24H','48H'):
        out['timeframe']=value['timeframe']
    events=value.get('capture_operations')
    for event in events[-24:] if isinstance(events,list) else ():
        if not isinstance(event,dict):continue
        duration=event.get('duration_seconds')
        if (isinstance(event.get('phase'),str) and event['phase'] in PHASES
            and isinstance(event.get('status'),str) and event['status'] in ('completed','failed')
            and type(duration) in (int,float) and math.isfinite(duration) and 0<=duration<=360):
            out['capture_operations'].append({key:event[key] for key in ('phase','status','duration_seconds')})
    return out


def _write_progress():
    if _progress_path is None or _progress_started is None:return
    payload=safe_progress({'format_version':'execution-progress.v1','stage':_current_stage,
        'elapsed_seconds':round(time.monotonic()-_progress_started,2),
        'capture_phase':_active_capture_phase,'capture_operations':list(_capture_events),**_progress_identity})
    if payload is None:return
    try:
        _progress_path.parent.mkdir(parents=True,exist_ok=True)
        temporary=_progress_path.with_suffix('.tmp')
        temporary.write_text(json.dumps(payload,allow_nan=False),encoding='utf-8')
        temporary.chmod(0o600);temporary.replace(_progress_path)
    except (OSError,ValueError):
        # Diagnostics cannot replace the original capture result or error.
        pass

@contextmanager
def capture_operation(phase):
    """Observe one existing operation; never change its call, timeout or pixels."""
    if phase not in PHASES:raise ValueError('Unknown capture phase')
    global _active_capture_phase
    started=time.monotonic();status='completed'
    previous_phase=_active_capture_phase;_active_capture_phase=phase;_write_progress()
    try:
        yield
    except Exception as exc:
        status='failed'
        if not hasattr(exc,'_model1_capture_phase'):exc._model1_capture_phase=phase
        raise
    finally:
        _capture_events.append({'phase':phase,'status':status,
            'duration_seconds':round(time.monotonic()-started,2)})
        del _capture_events[:-24]
        _active_capture_phase=previous_phase;_write_progress()

class StageFailure(RuntimeError):
    def __init__(self,code,reason=None):
        self.reason=reason if isinstance(reason,str) and reason in VALIDATION_REASONS else None
        self.code=code if code in CODES else 'worker_crashed'
        super().__init__(self.code)

def prepare_context(context):
    # A narrow host filter, never a wildcard block of source or authentication.
    context.route(AD_HOSTS,lambda route: route.abort())

def control(function,page,*args):
    phase={'_select_model_one':'model_selection','_select_symbol_mode':'symbol_selection',
           '_wait_for_heatmap':'wait_for_chart'}.get(function.__name__,'capture')
    if function.__name__=='_select_timeframe' and args and args[0] in ('12h','24h','48h'):
        phase='select_'+args[0]
    check_access=function.__name__=='_select_timeframe'
    def guard():
        if check_access:
            from capture_readiness import require_unblocked_source
            from heatmap_models import HEATMAP_MODEL
            require_unblocked_source(page,HEATMAP_MODEL,phase=phase)
    guard()
    try:
        result=function(page,*args)
    except Exception as exc:
        # CoinGlass can open the data-login dialog during a selector action.
        # Preserve other timeouts; never infer an access gate from header Login.
        guard()
        exc._model1_capture_phase=phase
        raise
    guard()
    return result

def stage(value):
    global _current_stage
    _current_stage=value if value in STAGES else 'startup'
    _write_progress()

def numeric_usage(raw):
    if not isinstance(raw,dict):return None
    return {k:v for k,v in raw.items() if k in {'input_tokens','output_tokens','total_tokens'}
            and type(v) is int and 0<=v<=2_000_000}

def accept_model_response(response):
    global _usage
    if not response.ok:
        status=response.status_code
        code={401:'analysis_unauthorized',403:'analysis_unauthorized',429:'analysis_rate_limited'}.get(status,'analysis_http_error')
        if status==429:
            try:
                if response.json().get('error',{}).get('code')=='insufficient_quota':code='analysis_quota_exceeded'
            except Exception:pass
        raise StageFailure(code)
    try:payload=response.json()
    except Exception:raise StageFailure('analysis_response_invalid') from None
    if not isinstance(payload,dict):raise StageFailure('analysis_response_invalid')
    _usage=numeric_usage(payload.get('usage'))
    if payload.get('status')=='incomplete':raise StageFailure('analysis_incomplete')
    if payload.get('status')!='completed':raise StageFailure('analysis_response_invalid')
    return payload

def remember_analysis(raw):
    global _usage,_analysis_facts
    if not isinstance(raw,dict):return
    _usage=numeric_usage(raw.get('usage')) or _usage
    scans=raw.get('scans')
    _analysis_facts={}
    if isinstance(scans,list):_analysis_facts['scan_count']=min(len(scans),100)
    if not isinstance(scans,list) or len(scans)!=1 or not isinstance(scans[0],dict):return
    scan=scans[0];facts=dict(_analysis_facts)
    facts['prominent_levels_present']='prominent_levels' in scan
    for key,allowed in {'observed_timeframe':{'12h','24h','48h','unknown'},
        'current_price_confidence':{'high','medium','low'},
        'blocking_condition':{'none','loading','login','blur','challenge','unknown'}}.items():
        value=scan.get(key)
        if isinstance(value,str) and value in allowed:facts[key]=value
    if type(scan.get('readable')) is bool:facts['readable']=scan['readable']
    _analysis_facts=facts

def safe_market_clip(value):
    if not isinstance(value, dict):
        return {}
    result = {}
    for key, length in (('viewport', 2), ('css_edges', 4), ('image_size', 2)):
        values = value.get(key)
        if (isinstance(values, (list, tuple)) and len(values) == length and
                all(type(x) is int and abs(x) <= 65536 for x in values)):
            result[key] = list(values)
    index = value.get('rect_index')
    if type(index) is int and 0 <= index <= 7:
        result['rect_index'] = index
    return result


def failure_detail(exc):
    inner=exc.__cause__ if exc.__cause__ is not None else exc
    kind=type(inner).__name__
    phase=getattr(exc,'_model1_capture_phase','capture')
    detail={'exception_kind':kind if kind in KINDS else 'other',
            'capture_phase':phase if phase in PHASES else 'capture'}
    reason=getattr(exc,'reason',None)
    if isinstance(reason,str) and reason in VALIDATION_REASONS:detail['validation_reason']=reason
    if detail.get('validation_reason') in MARKET_CLIP_REASONS:
        detail['market_clip'] = safe_market_clip(getattr(exc, 'market_clip', None))

    capture_state=getattr(exc,'_model1_source_capture_state',None)
    if capture_state is not None:
        from capture_failure_observer import safe_failure_state,CLICK_FAILURES
        detail['source_capture_state']=safe_failure_state(capture_state)
        click=getattr(exc,'_model1_click_failure',None)
        if isinstance(click,str) and click in CLICK_FAILURES:detail['click_failure']=click
    network=getattr(exc,'_model1_source_network',None)
    if network is not None:
        from capture_readiness import safe_network
        detail['source_network']=safe_network(network)
    readiness=getattr(exc,'_model1_source_readiness',None)
    if readiness is not None:
        from capture_readiness import safe_readiness,safe_network
        detail['source_readiness']=safe_readiness(readiness)
        detail['source_network']=safe_network(getattr(exc,'_model1_source_network',None))
        detail['readable']=False
        detail['blocking_condition']={'loading-indicator':'loading','blur':'blur','login-required':'login'}.get(
            detail['source_readiness']['reason'],'unknown')
    # Only recognize fixed strings from our own selector; don't retain any text.
    text=str(exc)
    if text.startswith('Could not find the visible CoinGlass timeframe selector'):
        detail['selector_issue']='trigger_missing'
    elif 'Visible option ' in text and 'did not appear after opening selector' in text:
        detail['selector_issue']='option_missing'
    elif 'Timeframe selection did not settle on ' in text:
        detail['selector_issue']='selection_not_settled'
    elif kind=='TimeoutError':detail['selector_issue']='action_timeout'
    return detail

def classify(exc):
    if isinstance(exc,StageFailure):return exc.code
    inner=exc.__cause__ if exc.__cause__ is not None else exc
    timeout=type(inner).__name__ in {'TimeoutError','Timeout','ReadTimeout','ConnectTimeout'}
    if _current_stage=='capture':return 'source_timeout' if timeout else 'source_capture_failed'
    if _current_stage=='analysis':return 'analysis_timeout' if timeout else 'analysis_response_invalid'
    if _current_stage=='image_check':return 'image_evidence_invalid'
    if _current_stage=='validation':
        if str(exc)=='Current price is not readable with sufficient confidence':return 'price_uncertain'
        return 'zones_invalid'
    return 'worker_crashed'

def run_task(main,timeframe,job_id,output):
    global _current_stage,_usage,_analysis_facts,_capture_events,_progress_path,_progress_started,_active_capture_phase,_progress_identity
    _current_stage='startup';_usage=None;_analysis_facts={};_capture_events=[]
    started=time.monotonic();root=Path(output)
    from heatmap_models import HEATMAP_MODEL
    _progress_identity={'heatmap_model':HEATMAP_MODEL,'timeframe':timeframe}
    _progress_path=root/'execution_progress.json';_progress_started=started;_active_capture_phase=None
    _write_progress()
    try:
        main(timeframe,job_id,output);return 0
    except Exception as exc:
        report={'code':classify(exc),'stage':_current_stage,
            'elapsed_seconds':round(time.monotonic()-started,2),'usage':_usage,
            **failure_detail(exc),**_analysis_facts,'capture_operations':list(_capture_events)}
        root.mkdir(parents=True,exist_ok=True);path=root/'error.json'
        path.write_text(json.dumps(report),encoding='utf-8');path.chmod(0o600)
        if _current_stage=='capture':
            try:
                from capture_failure_diagnostics import save_failure_diagnostics
                save_failure_diagnostics(exc,root,job_id=job_id,timeframe=timeframe,heatmap_model=HEATMAP_MODEL)
            except Exception:
                # Optional evidence cannot replace the existing error/outcome.
                pass
        return 1
    finally:
        _progress_path=None;_progress_started=None;_active_capture_phase=None;_progress_identity={}

def read_failure(path,job_id,returncode):
    report={'code':'worker_crashed','stage':'startup'}
    try:
        path=Path(path)
        if path.is_file() and not path.is_symlink() and path.stat().st_size<=4096:
            raw=json.loads(path.read_text())
            if isinstance(raw,dict):
                for key,allowed in {'code':CODES,'stage':STAGES,'capture_phase':PHASES,
                    'exception_kind':KINDS|{'other'},'validation_reason':VALIDATION_REASONS,
                    'selector_issue':{'trigger_missing','option_missing','selection_not_settled','action_timeout'},
                    'observed_timeframe':{'12h','24h','48h','unknown'},
                    'current_price_confidence':{'high','medium','low'},
                    'blocking_condition':{'none','loading','login','blur','challenge','unknown'}}.items():
                    val=raw.get(key)
                    if isinstance(val,str) and val in allowed:report[key]=val
                if report.get('validation_reason') in MARKET_CLIP_REASONS:
                    report['market_clip'] = safe_market_clip(raw.get('market_clip'))
                if type(raw.get('elapsed_seconds')) in (int,float) and 0<=raw['elapsed_seconds']<=360:
                    report['elapsed_seconds']=raw['elapsed_seconds']
                report['usage']=numeric_usage(raw.get('usage'))
                if type(raw.get('readable')) is bool:report['readable']=raw['readable']
                if type(raw.get('scan_count')) is int and 0<=raw['scan_count']<=100:
                    report['scan_count']=raw['scan_count']
                if type(raw.get('prominent_levels_present')) is bool:
                    report['prominent_levels_present']=raw['prominent_levels_present']
                if isinstance(raw.get('source_readiness'),dict):
                    from capture_readiness import safe_readiness,safe_network
                    report['source_readiness']=safe_readiness(raw['source_readiness'])
                    report['source_network']=safe_network(raw.get('source_network'))
                if isinstance(raw.get('source_capture_state'),dict):
                    from capture_failure_observer import safe_failure_state,CLICK_FAILURES
                    from capture_readiness import safe_network
                    report['source_capture_state']=safe_failure_state(raw['source_capture_state'])
                    report['source_network']=safe_network(raw.get('source_network'))
                    click=raw.get('click_failure')
                    if isinstance(click,str) and click in CLICK_FAILURES:report['click_failure']=click
                events=raw.get('capture_operations')
                if isinstance(events,list):
                    report['capture_operations']=[]
                    for event in events[-24:]:
                        if not isinstance(event,dict):continue
                        duration=event.get('duration_seconds')
                        if (isinstance(event.get('phase'),str) and event.get('phase') in PHASES
                            and event.get('status') in ('completed','failed')
                            and type(duration) in (int,float) and math.isfinite(duration) and 0<=duration<=360):
                            report['capture_operations'].append({'phase':event['phase'],
                                'status':event['status'],'duration_seconds':duration})
    except Exception:pass
    print('MODEL1_JOB_FAILURE '+json.dumps({'job_id':job_id,'exit_code':returncode,**report}),flush=True)
    return report['code']

CODES = CODES | frozenset({"price_range_uncertain", "price_range_too_wide", "no_unambiguous_zones", "evidence_store_failed"})
