"""Process the already captured, private BTC evidence once with the normal scanner and normalizer."""
from hashlib import sha256
import json
import os
from pathlib import Path
import re
import sys
import tempfile
import time
from uuid import UUID

# Match the parent allowlist. Addresses, CoinGlass sessions, DB and bridge credentials
# are never visible to the analysis process. An existing AI binding is used in place.
ANALYSIS_ENV = {'PATH','HOME','TMPDIR','LANG','LC_ALL','TZ','LD_LIBRARY_PATH','VIRTUAL_ENV',
                'SSL_CERT_FILE','SSL_CERT_DIR','REQUESTS_CA_BUNDLE','PYTHONDONTWRITEBYTECODE',
                'OPENAI_API_KEY','OPENAI_MARKET_SCANNER_MODEL'}

def analyze(run_id,sha):
    from retained_evidence import MAX_IMAGE, MAX_JSON, bounded_read, require, safe_root, unpack, write_once
    from modern_map_task import summary_schema, normalized_summary, interpretation_inputs
    from market_vision import openai_heatmap_scanner as scanner
    from cg_chart_qa_cost import guard_chart_post
    from unittest.mock import patch
    require(str(UUID(run_id))==run_id and bool(re.fullmatch('[0-9a-f]{64}',sha)))
    d=safe_root(); blob=bounded_read(d/(run_id+'.map'),MAX_IMAGE+MAX_JSON+520)
    require(sha256(blob).hexdigest()==sha)
    snap,image=unpack(blob,run_id)
    out=d/(run_id+'.result.json')
    if out.exists():
        result=json.loads(bounded_read(out,3*MAX_JSON)); require(result['run_id']==run_id and result['evidence']['sha256']==sha256(image).hexdigest());return 'already_saved'
    supplement = d / (run_id + '.overview.json')
    overview = json.loads(bounded_read(supplement, MAX_JSON)) if supplement.exists() else None
    raw_path = d / (run_id + '.verdict.json')
    if raw_path.exists():
        # Resume normalization or publication against the same immutable market snapshot.
        retained = json.loads(bounded_read(raw_path, 3 * MAX_JSON))
        require(retained['market_sha256'] == sha)
        raw = retained['verdict']
    else:
        require(bool(os.environ.get('OPENAI_API_KEY')))
        description, candidates = interpretation_inputs(snap, overview)
        with tempfile.TemporaryDirectory(dir=d) as td:
            p = Path(td) / 'image.png'
            p.write_bytes(image)
            try:
                write_once(d, run_id + '.analysis-started', sha.encode())
            except FileExistsError:
                return 'analysis_outcome_pending'
            guarded, stats = guard_chart_post(scanner.requests.post, sha256(image).hexdigest())
            start = time.monotonic()
            try:
                with patch.object(scanner.requests, 'post', guarded):
                    raw = scanner.analyze_heatmap_images(
                        [dict(image=str(p), timeframe='12H', measure_candidates=candidates)],
                        symbol='BTC', timeout_seconds=65, evidence_schema=summary_schema(),
                        evidence_instructions=description)
                charged = raw.get('usage') or {}
                if isinstance(charged, dict):
                    for key in ('input_tokens','output_tokens'):
                        if type(charged.get(key)) is int:
                            stats[key] = charged[key]
                    details = charged.get('input_tokens_details') or {}
                    for name in ('cached_tokens','cache_write_tokens'):
                        if isinstance(details, dict) and type(details.get(name)) is int:
                            stats[name] = details[name]
                write_once(d, raw_path.name, json.dumps(
                    {'market_sha256': sha, 'verdict': raw}, allow_nan=False,
                    separators=(',', ':')).encode())
            finally:
                stats['elapsed_seconds'] = round(time.monotonic()-start, 3)
                write_once(d, run_id + '.analysis-budget.json', json.dumps(stats,allow_nan=False).encode())
    result = normalized_summary(raw, snap, run_id, image, overview)
    write_once(d, out.name, json.dumps(result, allow_nan=False, separators=(',', ':')).encode())
    return 'analysis_saved'

if __name__=='__main__':
    os.umask(0o077)
    clean={k:v for k,v in os.environ.items() if k in ANALYSIS_ENV}
    if clean!=dict(os.environ):os.execve(sys.executable,[sys.executable,'-B',str(Path(__file__).resolve()),*sys.argv[1:]],clean)
    sys.path.insert(0,str(Path(__file__).resolve().parent/'runtime'))
    try: print(analyze(*sys.argv[1:]))
    except Exception: print('analysis_preflight_or_result_failed');raise SystemExit(1)
