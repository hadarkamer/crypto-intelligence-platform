"""One isolated, post-capture scan on the owner's existing analyst, using a market-only vault entry."""
import base64
import hashlib
import json
import os
from pathlib import Path
import re
import subprocess
import sys
from uuid import UUID

HERE=Path(__file__).resolve().parent
sys.path.insert(0,str(HERE/'runtime'))

def child(job,digest):
    from analyze_retained_map import ANALYSIS_ENV,analyze
    from retained_evidence import safe_root,bounded_read,MAX_JSON
    if set(os.environ)-ANALYSIS_ENV:
        raise ValueError('unexpected_analysis_env')
    status=analyze(job,digest)
    root=safe_root()
    if status not in ('already_saved','analysis_saved'):
        print(json.dumps({'status':status}));return
    raw=bounded_read(root/(job+'.result.json'),3*MAX_JSON)
    data=json.loads(raw)
    if (data.get('run_id'),data.get('symbol'),data.get('heatmap_model'),data.get('timeframe'),data.get('provider'))!=(job,'BTC',1,'12H','OpenAI'):
        raise ValueError('result_binding_invalid')
    print(json.dumps(dict(job_id=job,artifact_sha256=data['evidence']['sha256'],
        result_sha256=hashlib.sha256(raw).hexdigest(),result_b64=base64.b64encode(raw).decode('ascii')),separators=(',',':')))

def main():
    if len(sys.argv)!=5:raise ValueError('args')
    phase,job,digest,oid=sys.argv[1:]
    if str(UUID(job))!=job or not re.fullmatch(r'[0-9a-f]{64}',digest) or not re.fullmatch(r'[0-9]{1,10}',oid):
        raise ValueError('args')
    os.umask(0o077)
    if phase=='_chart_child':return child(job,digest)
    if phase!='settle':raise ValueError('phase')
    from psycopg import connect
    from psycopg.rows import dict_row
    from market_vault import retrieve, analysis_record
    from retained_evidence import safe_root, bounded_read, MAX_IMAGE, MAX_JSON, write_once
    from analyze_retained_map import ANALYSIS_ENV
    have_key=bool(os.environ.get('OPENAI_API_KEY'))
    if not have_key:
        print('{"status":"analyst_binding_absent"}');return
    root = safe_root()

    def local_file(name, data, bound):
        path = root / name
        if path.exists():
            if bounded_read(path, bound) != data:
                raise ValueError('prior_market_file_differs')
        else:
            write_once(root, name, data)

    with connect(os.environ['DATABASE_URL'],autocommit=True,connect_timeout=4,row_factory=dict_row) as conn:
        key = base64.b64decode(os.environ['COINGLASS_SESSION_KEY'],validate=True)
        blob = retrieve(conn,key,job,digest,int(oid))
        from retained_evidence import unpack
        from modern_map_task import interpretation_inputs
        snapshot, _ = unpack(blob, job)
        local_file(job+'.map',blob,MAX_IMAGE+MAX_JSON+520)
        # Source-only typed DOM record; project it through the validator again
        # before any values can leave this machine or reserve a request.
        overview = None
        supplemental = Path('/tmp/cg-budget/market-supplement.json')
        if supplemental.exists():
            data = json.loads(bounded_read(supplemental,MAX_JSON))
            if data.get('job_id') != job or data.get('source_time') != snapshot['source_time']:
                raise ValueError('supplemental_binding_mismatch')
            overview = data.get('overview')
            if not isinstance(overview, dict) or overview.get('source_time') != snapshot['source_time']:
                raise ValueError('supplemental_overview_mismatch')
            local_file(job+'.overview.json',json.dumps(overview,allow_nan=False,separators=(',',':')).encode(),MAX_JSON)
        interpretation_inputs(snapshot,overview)
        suffices = {'verdict':'.verdict.json','budget':'.analysis-budget.json','result':'.result.json'}
        for kind, suffix in suffices.items():
            _, saved = analysis_record(conn,key,job,digest,kind)
            if saved is not None:
                local_file(job+suffix,saved,3*MAX_JSON)
        created, _ = analysis_record(conn,key,job,digest,'claim',b'reserved')
        if not created and not any((root/(job+suffices[k])).exists() for k in ('result','verdict')):
            print('{"status":"analysis_outcome_pending"}');return

        clean={k:v for k,v in os.environ.items() if k in ANALYSIS_ENV}
        try:
            proc=subprocess.run([sys.executable,'-B',str(Path(__file__).resolve()),'_chart_child',job,digest,oid],
                env=clean,cwd=HERE,stdin=subprocess.DEVNULL,capture_output=True,timeout=85,check=False)
        finally:
            for kind, suffix in suffices.items():
                file = root/(job+suffix)
                if file.exists():
                    analysis_record(conn,key,job,digest,kind,bounded_read(file,3*MAX_JSON))
    if proc.returncode!=0:
        meta=root/(job+'.analysis-budget.json')
        budget=json.loads(bounded_read(meta,4096)) if meta.exists() else {}
        print(json.dumps(dict(status='chart_analysis_incomplete',calls=budget.get('requests',0),
            cost_ceiling_usd=budget.get('cost_ceiling_usd')),separators=(',',':')))
        return
    result=json.loads(proc.stdout)
    if set(result)=={'status'}:print(json.dumps(result));return
    if set(result)!={'job_id','artifact_sha256','result_sha256','result_b64'} or result['job_id']!=job:raise ValueError('bad_receipt')
    candidate=base64.b64decode(result['result_b64'],validate=True)
    if hashlib.sha256(candidate).hexdigest()!=result['result_sha256']:raise ValueError('bad_result_sha')
    path=HERE/'normalized-market-receipt.json'
    if path.exists():
        if json.loads(bounded_read(path,5*MAX_JSON))!=result:raise ValueError('prior_receipt_differs')
    else:write_once(HERE,path.name,json.dumps(result,separators=(',',':')).encode())
    print(json.dumps(dict(status='verified_market_result',job_id=job,result_sha256=result['result_sha256'],
        artifact_sha256=result['artifact_sha256'],usage=json.loads(candidate).get('usage'),
        budget=json.loads(bounded_read(root/(job+'.analysis-budget.json'),4096))),separators=(',',':')))

if __name__=='__main__':
    try:main()
    except BaseException as exc:
        # Captures even timeout paths without leaking nested HTTP/DB diagnostics.
        print(json.dumps({'status':'chart_worker_failed','error_type':type(exc).__name__}));sys.exit(2)
