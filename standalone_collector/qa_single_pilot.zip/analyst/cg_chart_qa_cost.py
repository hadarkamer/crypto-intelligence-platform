"""Ephemeral post-capture guard for the existing CoinGlass chart-only scanner."""
import base64
import copy
import datetime
import hashlib
import json
import math
import re
import struct


class ChartBudgetError(ValueError):
    pass


def guard_chart_post(transport, expected_png_sha256):
    """Return a replacement for scanner.requests.post and a non-sensitive estimate.

    Bind to the already-masked, retained PNG and the existing single-model request.
    One attempt, including failures, with ordinary global standard endpoint pricing.
    """
    if not re.fullmatch(r'[a-f0-9]{64}', expected_png_sha256):
        raise ChartBudgetError('missing_chart_sha')
    stats = {'requests': 0}

    def post(url, **kwargs):
        body = kwargs.get('json')
        date = datetime.datetime.now(datetime.timezone.utc).date()
        if (stats['requests'] or url != 'https://api.openai.com/v1/responses'
                or kwargs.get('allow_redirects') is not False or not isinstance(body, dict)
                or set(body) != {'model', 'store', 'max_output_tokens', 'reasoning', 'instructions', 'input', 'text'}
                or body.get('model') not in ('gpt-5.6', 'gpt-5.6-sol')
                or body.get('store') is not False or date>datetime.date(2026, 11, 30)
                or body.get('text', {}).get('format', {}).get('name') != 'coinglass_heatmap_scan'):
            raise ChartBudgetError('chart_transport_or_pricing_unsupported')
        filtered = copy.deepcopy(body)
        inputs = filtered['input']
        if len(inputs)!=1 or inputs[0].get('role')!='user':
            raise ChartBudgetError('unexpected_chart_input')
        blocks = inputs[0]['content']
        images = [b for b in blocks if b.get('type') == 'input_image']
        if len(images)!=1 or len(blocks)>10 or any(b.get('type') not in ('input_text','input_image') for b in blocks):
            raise ChartBudgetError('unexpected_chart_blocks')
        image = images[0]
        prefix = 'data:image/png;base64,'
        if image.get('detail')!='original' or not image.get('image_url','').startswith(prefix):
            raise ChartBudgetError('unexpected_chart_image')
        encoded = image.pop('image_url')[len(prefix):]
        if not 0<len(encoded)<=6*1024*1024:
            raise ChartBudgetError('chart_image_size')
        png=base64.b64decode(encoded,validate=True)
        if (len(png)<24 or png[:8]!=b'\x89PNG\r\n\x1a\n' or png[12:16]!=b'IHDR'
                or hashlib.sha256(png).hexdigest()!=expected_png_sha256):
            raise ChartBudgetError('chart_image_binding')
        width,height=struct.unpack('>II',png[16:24])
        if not 0<width<=4096 or not 0<height<=4096:
            raise ChartBudgetError('chart_dimensions')
        # UTF-8 byte upper bound for the entire serialized non-image payload, plus
        # a 1024-token reserve for request framing and schema serialization.
        text_bound=len(json.dumps(filtered,ensure_ascii=True).encode('ascii')) + 1024
        image_bound=math.ceil(1.2*math.ceil(width/32)*math.ceil(height/32))+2
        input_bound=text_bound+image_bound
        # Short context, $5/M worst-case cache-write and $20/M output. Allow
        # an additional 10% on both and retain a final $0.001 safety margin.
        micro_budget=49_000
        cap=min(12000, (10*micro_budget-55*input_bound)//220)
        if cap<256:
            raise ChartBudgetError('chart_does_not_fit_approved_cost')
        safe=dict(body, max_output_tokens=cap, service_tier='default')
        stats.update(requests=1,input_token_bound=input_bound,output_token_cap=cap,
                     cost_ceiling_usd=round((55*input_bound+220*cap)/10_000_000,7))
        response = transport(url, **dict(kwargs, json=safe))
        stats['model'] = body['model']
        stats['http_status'] = response.status_code if type(response.status_code) is int else None
        try:
            payload = response.json()
            usage = payload.get('usage') or {}
            details = usage.get('input_tokens_details') or {}
            for key in ('input_tokens','output_tokens'):
                if type(usage.get(key)) is int:
                    stats[key] = usage[key]
            for key in ('cached_tokens','cache_write_tokens'):
                if type(details.get(key)) is int:
                    stats[key] = details[key]
        except (AttributeError, TypeError, ValueError):
            pass
        return response
    return post,stats
