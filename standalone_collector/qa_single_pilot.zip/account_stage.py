"""One-host account-only experiment. No database write. Only ciphertext may be stored."""
import os
import re
import stat
from uuid import UUID


def _codec(key, slot, run_id):
    from session_state import PgSessionStore
    if not re.fullmatch(r'email-v1:[0-9a-f]{64}', slot) or str(UUID(run_id)) != run_id:
        raise ValueError('stage_identity_invalid')
    codec=PgSessionStore(None,key)
    # Distinct associated data makes a staging envelope unusable as product protected-map proof.
    codec.slot='auth-only-stage-v1:'+slot+':'+run_id
    return codec


def _folder(path):
    fd=os.open(path,os.O_RDONLY|os.O_DIRECTORY|os.O_NOFOLLOW|os.O_CLOEXEC)
    meta=os.fstat(fd)
    if meta.st_uid!=os.geteuid() or stat.S_IMODE(meta.st_mode)!=0o700:
        os.close(fd)
        raise ValueError('stage_private_directory_required')
    return fd


def save(path,key,slot,run_id,state,*,account_verified):
    if account_verified is not True:
        raise ValueError('stage_account_proof_required')
    encrypted=_codec(key,slot,run_id)._seal(state,1).encode('ascii')
    folder=_folder(path)
    try:
        fd=os.open('account-only.enc',os.O_WRONLY|os.O_CREAT|os.O_EXCL|os.O_NOFOLLOW|os.O_CLOEXEC,0o600,dir_fd=folder)
        with os.fdopen(fd,'wb') as target:
            target.write(encrypted)
            target.flush()
            os.fsync(target.fileno())
        os.fsync(folder)
    finally:
        os.close(folder)


def load(path,key,slot,run_id):
    from session_state import STATE_LIMIT
    folder=_folder(path)
    try:
        fd=os.open('account-only.enc',os.O_RDONLY|os.O_NOFOLLOW|os.O_CLOEXEC,dir_fd=folder)
        with os.fdopen(fd,'rb') as source:
            meta=os.fstat(source.fileno())
            if (not stat.S_ISREG(meta.st_mode) or meta.st_nlink!=1 or meta.st_uid!=os.geteuid()
                    or stat.S_IMODE(meta.st_mode)!=0o600 or not 0<meta.st_size<=2*STATE_LIMIT):
                raise ValueError('stage_file_invalid')
            encrypted=source.read(2*STATE_LIMIT+1)
    finally:
        os.close(folder)
    return _codec(key,slot,run_id)._open(encrypted.decode('ascii'),1)
