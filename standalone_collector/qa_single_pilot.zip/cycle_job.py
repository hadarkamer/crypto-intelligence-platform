"""Use only the authenticated triggering app job, written once by the bounded QA supervisor."""
import json
import os
from pathlib import Path
import stat
from uuid import UUID
from functools import lru_cache

PARENT=Path('/tmp/cg-budget')
def read_job(root,service):
    flags=os.O_CLOEXEC|os.O_NOFOLLOW|os.O_RDONLY
    directory=os.open(root,flags|os.O_DIRECTORY)
    try:
        parent=os.fstat(directory)
        if parent.st_uid!=os.geteuid() or stat.S_IMODE(parent.st_mode) not in (0o700,0o2700):raise ValueError('untrusted_trigger_directory')
        fd=os.open('ui_job.json',flags,dir_fd=directory)
        with os.fdopen(fd,'rb') as f:
            meta=os.fstat(f.fileno())
            if not (stat.S_ISREG(meta.st_mode) and meta.st_uid==os.geteuid() and stat.S_IMODE(meta.st_mode)==0o600 and
                    meta.st_nlink==1 and 0<meta.st_size<=2000):raise ValueError('untrusted_trigger_record')
            data=f.read(2001)
    finally:os.close(directory)
    def unique(items):
        fields=dict(items)
        if len(fields)!=len(items):raise ValueError('duplicate_trigger_field')
        return fields
    event=json.loads(data,object_pairs_hook=unique)
    uid=event.get('job_id')
    if not (type(event) is dict and set(event)=={'service','job_id','origin','symbol','model','timeframe'} and
            event['service']==service and event['origin']=='test_application' and event['symbol']=='BTC' and
            type(event['model']) is int and event['model']==1 and event['timeframe']=='12H' and
            isinstance(uid,str) and str(UUID(uid))==uid and UUID(uid).int!=0):
        raise ValueError('invalid_application_trigger')
    return uid

@lru_cache(maxsize=1)
def current_job():
    import runner
    return read_job(PARENT,runner.SVC)
